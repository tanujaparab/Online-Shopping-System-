<?php
  if(isset($_POST['newquantity'])) {
	  $newQuantity = $_POST['newquantity'];
	  $productIndex = $_POST['productIndex'];
	  $cartType = $_POST['cartType'];
	  
	    session_start();
	  if(isset($_SESSION["userId"])) {
		  $custId = $_SESSION["userId"];
		  include("include-files/dbConnection.php");
		  
		  $qry2 = mysqli_query($con,"select * from customers where custId='$custId'");
	      $res2 = mysqli_fetch_array($qry2);
	      $accCartQty = $res2["cartQtys"];
		  
		  $qtyArray = explode("_",$accCartQty);
		  $qtyArray[$productIndex] = $newQuantity;
		  $accCartQty = implode("_",$qtyArray);
		  
		  $updateQry = mysqli_query($con,"update customers set cartQtys='$accCartQty' where custId='$custId'");
	  } else {
		  	  
	      $quantities = $_COOKIE['quantities'];
	      $qtyArray = explode("_",$quantities);
	      $qtyArray[$productIndex] = $newQuantity;
	      $quantities = implode("_",$qtyArray);
	      setcookie("quantities",$quantities,time()+(86400*60)); 
	  }  
 
 
	/*  $cartItems = $_COOKIE['cartItems'];
	  $productArray = explode("_",$cartItems);
	  $productCount = count($productArray);
	  $noOfProducts = --$productCount; //Neglecting first 0 by decreament
	 
	  
	  $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
	  
	  	  
	  function getCartProduct($qry,$i) {
		 $res = mysqli_fetch_row($qry);
		$proPrize = $res[0];
		  
		$quantities = $_COOKIE['quantities'];
		$qtyArray = explode("_",$quantities);
		// $qty = $qtyArray[$i]; 
		
		global $totalAmount;
		//----------calculating total amount according to qtys----------
	    $totalAmount = $totalAmount + ($proPrize * $qtyArray[$i]); 		
	  }
	  
	  $i = 1;
	  while($i < $noOfProducts) {
		  if($productArray[$i] >= 10101 && $productArray[$i] <= 20100){
			  $qry = mysqli_query($con,"select productPrize from mobiles where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i);
		   } else if($productArray[$i] >= 20101 && $productArray[$i] <= 25100) {
			  $qry = mysqli_query($con,"select productPrize from menswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i); 
		   } else if($productArray[$i] >= 25101 && $productArray[$i] <= 30100) {
			  $qry = mysqli_query($con,"select productPrize from ladieswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i); 
		   } else if($productArray[$i] >= 30101 && $productArray[$i] <= 35100) {
			  $qry = mysqli_query($con,"select productPrize from childrenswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i); 
		   } else if($productArray[$i] >= 25101 && $productArray[$i] <= 40100) {
			  $qry = mysqli_query($con,"select productPrize from sportswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i); 
		   } else if($productArray[$i] >= 40101 && $productArray[$i] <= 50100) {
			  $qry = mysqli_query($con,"select productPrize from watches where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i); 
		   } else if($productArray[$i] >= 50101 && $productArray[$i] <= 60100) {
			  $qry = mysqli_query($con,"select productPrize from books where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i); 
		   } 
			
		 $i++;
	  }
	  
	  echo $totalAmount;  */
  }
?>