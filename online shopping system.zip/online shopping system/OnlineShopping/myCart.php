<!DOCTYPE html>
<html>
 <head>
  <title>
	 My Cart
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css"> 
  <link rel="stylesheet" type="text/css" href="css/myCart.css">
	
 <script src="jquery-3.3.1.min.js"></script>
 <script>
	$(document).ready(function() {
	<?php 
		if(isset($_SESSION["userId"])) {
		  $custId = $_SESSION["userId"];
		  $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
		  
		  $qry2 = mysqli_query($con,"select * from customers where custId='$custId'");
	      $res2 = mysqli_fetch_array($qry2);
	      $accCartItems = $res["cartProducts"];
		  $productArray = explode("_",$accCartItems);
		  $productCount = count($productArray); 
			
		} else if(isset($_COOKIE['cartItems']) && ($_COOKIE['cartItems'] != '0')){
			$cartItems = $_COOKIE['cartItems'];  
		    $productArray = explode("_",$cartItems);
		    $productCount = count($productArray);
		//	session_destroy();
		} else {
			
		} 
		
		$cartType = 1;
		for($x=1; $x<$productCount; $x++) { ?>
		$("#upCart<?php echo $x; ?>").on("change keyup",function() {
			 var newqty = $("#upCart<?php echo $x; ?>").val();
			 var proIndex = <?php echo $x; ?> ;
			 if(newqty <= 0 || newqty > 3) {
				alert("Enter quantity between 1 to 3 only");
				var newqty = $("#upCart<?php echo $x; ?>").val(1);
			 } else {
				$.post("updateCart.php",{
					newquantity : newqty ,
					productIndex : proIndex,
					cartType : <?php echo $cartType; ?>
				}, function(data,status){
					 document.location.reload(true);
					// $("#tAmount").html(data);
				});
			 }
		});
	 <?php } ?>
	});
</script>
 </head>
	
 <body>
  <div id="wrapper">
   <!---------------Header Content---------------------->
	  
	  <?php  include("include-files/header.php"); ?>
	  
   <!---------------Product Categories--------------------->
		
	  <?php  include("include-files/productCategoryBox.php");  ?>

 <div id="showCartBox">
	<?php
	  $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
	 
	       $count = 1;
	 
	      function getCartProduct($qry,$i,$accCartQty) { 		  
			  GLOBAL $count;
			
			if(isset($_SESSION['userId'])) {
				$quantities = $accCartQty;
			    $qtyArray = explode("_",$quantities);
			    $qty = $qtyArray[$i];
			} else {
			    $quantities = $_COOKIE['quantities'];
			    $qtyArray = explode("_",$quantities);
			    $qty = $qtyArray[$i];			
			}

			  
		    $res = mysqli_fetch_row($qry);
			echo "<tr>";
			  echo "<td class='SerNo'>$i</td>";
			   echo "<td class='proImg'><img src='$res[3]' width='40' height='70'></td>";
			   echo "<td class='proName'><a href='product-files/viewProduct.php?proId=$res[0]'>$res[1]</a></td>";
			   echo "<td class='prodPrize'>&#8377; $res[2]/-</td>";
			   echo "<td class='proQuantity'>
                       <input type='number' value='$qty' name='quantity' min='1' max='3' id='upCart$count'>
			         </td>";
		       echo "<td class='proRemove'><a href='removeFromCart.php?removeProId=$res[0]'>Remove</a></td>";
			echo "</tr>";
			 
			$count++;
			global $totalAmount;
			//----------calculating total amount according to qtys----------
			$totalAmount = $totalAmount + ($qty * $res[2]); 
	    }
		 
	 
	  // error_reporting(0);
	  if(isset($_SESSION['userId'])) {
		 $custId = $_SESSION["userId"];
		 $qry = mysqli_query($con,"select * from customers where custId='$custId'");
		 $res = mysqli_fetch_array($qry);
		 $accCartItems = $res["cartProducts"];
		 $accCartQty = $res["cartQtys"];
		  
		 if($accCartItems != "0" || $accCartQty != "0") {
           $productArray = explode("_",$accCartItems);
		   $productCount = count($productArray);
		   $noOfProducts = --$productCount; //Neglecting first 0 by decreament
		  
		   echo "<div id='cartItemsBox'>";
		  
		  echo "<div id='totalItems'>Total Cart Products : ".$noOfProducts."</div><br>";
		
		  echo "<table id='cartItemsTable'>";
		  echo "<tr>";
		  echo "<th>No.</th>";
		  echo "<th>Item</th>";
		  echo "<th>Name</th>";
		  echo "<th>Prize</th>";
		  echo "<th>Quantity</th>";
		  echo "<th></th>"; 
		 echo "</tr>";
		  
		$i = 1;  
		while($i <= $noOfProducts) {

		   if($productArray[$i] >= 10101 && $productArray[$i] <= 20100){
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from mobiles where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,$accCartQty);
		   } else if($productArray[$i] >= 20101 && $productArray[$i] <= 25100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from menswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,$accCartQty); 
		   } else if($productArray[$i] >= 25101 && $productArray[$i] <= 30100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from ladieswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,$accCartQty); 
		   } else if($productArray[$i] >= 30101 && $productArray[$i] <= 35100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from childrenswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,$accCartQty); 
		   } else if($productArray[$i] >= 25101 && $productArray[$i] <= 40100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from sportswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,$accCartQty); 
		   } else if($productArray[$i] >= 40101 && $productArray[$i] <= 50100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from watches where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,$accCartQty); 
		   } else if($productArray[$i] >= 50101 && $productArray[$i] <= 60100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, bookCategory from books where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,$accCartQty); 
		   } 
			
		 $i++;
		}
		echo "</table>";
       echo "</div>";
		  
	   //
		  
	   echo "<div id='totalAmount'>Total Amount : &#8377; <span id='tAmount'>".$totalAmount."</span>/-</div>";
		 echo "<a href='loginCheck.php'><button id='checkOutButton'>Proceed To Checkout</button></a>";
	   } else {
			 echo "<div id='emptyCartMsg'>Your cart is Empty...!!</div>";
	   }
		  
	  } else if(isset($_COOKIE['cartItems']) && ($_COOKIE['cartItems'] != '0')) {
		  
		$cartItems = $_COOKIE['cartItems'];  
		$productArray = explode("_",$cartItems);
		$productCount = count($productArray);
		$noOfProducts = --$productCount; //Neglecting first 0 by decreament
		  
		echo "<div id='cartItemsBox'>";
		  
		echo "<div id='totalItems'>Total Cart Products : ".$noOfProducts."</div><br>";
		
		echo "<table id='cartItemsTable'>";
		echo "<tr>";
		  echo "<th>No.</th>";
		  echo "<th>Item</th>";
		  echo "<th>Name</th>";
		  echo "<th>Prize</th>";
		  echo "<th>Quantity</th>";
		  echo "<th></th>"; 
		echo "</tr>";
		  
		$i = 1;  
		while($i <= $noOfProducts) {

		   if($productArray[$i] >= 10101 && $productArray[$i] <= 20100){
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from mobiles where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,null);
		   } else if($productArray[$i] >= 20101 && $productArray[$i] <= 25100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from menswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,null); 
		   } else if($productArray[$i] >= 25101 && $productArray[$i] <= 30100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from ladieswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,null); 
		   } else if($productArray[$i] >= 30101 && $productArray[$i] <= 35100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from childrenswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,null); 
		   } else if($productArray[$i] >= 25101 && $productArray[$i] <= 40100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from sportswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,null); 
		   } else if($productArray[$i] >= 40101 && $productArray[$i] <= 50100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, brandName from watches where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,null); 
		   } else if($productArray[$i] >= 50101 && $productArray[$i] <= 60100) {
			  $qry = mysqli_query($con,"select productId, productName, productPrize,      image, bookCategory from books where productId='$productArray[$i]'"); 
			  getCartProduct($qry,$i,null); 
		   } 
			
		 $i++;
		}
		echo "</table>";
       echo "</div>";
		  
	   echo "<div id='totalAmount'>Total Amount : &#8377; <span id='tAmount'>".$totalAmount."</span>/-</div>";
		 echo "<a href='loginCheck.php'><button id='checkOutButton'>Proceed To Checkout</button></a>";
		 
	  } else {
		  echo "<div id='emptyCartMsg'>Your cart is Empty...!!</div>";
	  } 
	?>
 </div>
	  
 </div>
</body>
</html>