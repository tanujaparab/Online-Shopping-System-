<!DOCTYPE html>
<html>
 <head>
  <title>
	 Shop Online - Home
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" type="text/css" href="css/login.css"> 
 </head>
	
  <body>
   <div id="wrapper">
	 <div id="header">
        <div id="logo">
	     <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/></a> 
        </div>
     </div>
		

<?php
 if(isset($_POST['loginSubmit'])) {
   $con = mysqli_connect("localhost","root","","onlineshopping") or        
	      die(mysqli_connect_error());
	 
   function addCartProducts($x) {
	  $custId  = $x;
	   
	  if(isset($_COOKIE['cartItems']) && ($_COOKIE['cartItems'] != '0')) {
	      $con = mysqli_connect("localhost","root","","onlineshopping") or        
	      die(mysqli_connect_error());		  
		  
		 $cartItems = $_COOKIE['cartItems'];
		 $quantities = $_COOKIE['quantities'];
		 
		 $cartItemsArray = explode("_",$cartItems);
		 $qtyArray = explode("_",$quantities);
		 
		 $qry = mysqli_query($con,"select * from customers where custId='$custId'");
		 $res = mysqli_fetch_array($qry);
		 $accCartItems = $res["cartProducts"];
		 $accCartQty = $res["cartQtys"]; 
		  
		 if($accCartItems == "0" && $accCartQty == "0") {
		  	 $updateQry = mysqli_query($con,"update customers set cartProducts='$cartItems', cartQtys='$quantities' where custId='$custId'");
			 
			 setcookie("cartItems","0",time()+(86400*60));
	         setcookie("quantities","0",time()+(86400*60));   
		 } else {
			 unset($cartItemsArray[0]);
			 unset($qtyArray[0]);
			 
			 $cartItems = implode("_",$cartItemsArray);
			 $quantities = implode("_",$qtyArray);
			 
			 $newCartString = $accCartItems.'_'.$cartItems;
			 $newQtyString = $accCartQty.'_'.$quantities;
			 
			 $updateQry = mysqli_query($con,"update customers set cartProducts='$newCartString', cartQtys='$newQtyString' where custId='$custId'");
			 
			 setcookie("cartItems","0",time()+(86400*60));
	         setcookie("quantities","0",time()+(86400*60));
			 
			 mysqli_close($con);  
		 }
		 
	  }
   }
   
   
   $email = mysqli_real_escape_string($con, $_POST['email']);
   $pass = mysqli_real_escape_string($con, $_POST['pass']);
	 
   $pass = md5($pass);   //-----Password Encryption--------
   
   //-------------Checking if email is correct or not----------------
	$sql = mysqli_query($con,"select * from customers where email='$email'");
	$rowsCount = mysqli_num_rows($sql);
	if($rowsCount > 0) {
		$sql = mysqli_query($con,"select * from customers where email='$email' &&   
		       password='$pass'");
		$rowsCount = mysqli_num_rows($sql);
		if($rowsCount > 0) {
			$res = mysqli_fetch_array($sql);
			$custId = $res['custId'];
			$fname = $res['firstName'];
			
			session_start();
			$_SESSION["loginSession"] = "on";
			$_SESSION["userId"] = $custId;
			$_SESSION["firstName"] = $fname;
			
			// -----------adding cart products to cust account cart----------
			addCartProducts($custId);
				
		    if(isset($_REQUEST['loginStatus'])) {
				if($_REQUEST['loginStatus'] == "forCheckout") {
					header("location:placeOrder.php"); 
				} else {
					header("location:index.php"); 
				}
			} else {
			  // header("location:index.php"); 
			}
		} else {
			echo "<div id='msgBox'>";
		    echo "Incorrect Password..<br><br>";
		    echo "<a href='login.php'>Login Again</a>";
		    echo "</div>";
		    mysqli_close($con);
		}
		
	} else {
		 echo "<div id='msgBox'>";
		 echo "Incorrect Email..<br><br>";
		 echo "<a href='login.php'>Login Again</a>";
		 echo "</div>";
		 mysqli_close($con);
	}
  } else {
	  header("location:login.php");
 }
?>
	   
   </div>  
  </body>
</html>



