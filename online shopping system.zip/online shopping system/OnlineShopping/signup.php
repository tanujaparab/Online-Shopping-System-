<?php
  session_start();
  if(isset($_SESSION['userId'])) {
	  header("location:index.php");
  } else {
	  
?> 

<!DOCTYPE html>
<html>
 <head>
  <title>
	 Sign Up
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css"> 
  <link rel="stylesheet" type="text/css" href="css/login.css"> 
  <script type="text/javascript">
    function signUpValidate() { 
		if(document.signUpForm.mobileNo.value.length != 10) {
		   var mob = document.forms["signUpForm"]["mobileNo"];
		   alert( "Please provide Mobile No. with 10 Digits" );
           mob.focus() ;
           return false;
		}
		
		if(document.signUpForm.pinCode.value.length != 6) {
		   var pin = document.forms["signUpForm"]["pinCode"];
		   alert( "Please provide Pincode No. with 6 Digits" );
           pin.focus() ;
           return false;
		}
	}	 
 </script>
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content------=--------------->
	  
	  <div id="header">
  <div id="logo">
	 <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/>
     </a>
  </div>
	
  <div id="rightHeaderBox">
	<a href="myCart.php">
     <div id="cartBox"><img src="images/emptyCartLight.png" width="36" height="36" 
                        align="middle"/>
	   <span id="cartText">
		 Cart 
		 <span id="cartCount">
         <?php
		   if(isset($_COOKIE['cartItems'])) {
			 $cartItems = $_COOKIE['cartItems'];
			 $productArray = explode("_",$cartItems);
             $noOfProducts = count($productArray);
             $noOfProducts = --$noOfProducts;
			 echo $noOfProducts;
           } else {
              echo "0";
           }
         ?>
          </span>
	   </span>
      </div>
	 </a>

	 <a href="login.php">
       <div id="loginButton">
          Login
       </div>
	 </a>
  </div>
	
  <div id="searchBar">
    <input type="text" id="searchBox" placeholder="Search products..."                        name="searchProduct">
	<button id="searchButton"><img src="images/searchIcon.png" width="19" height="19">
	</button>
  </div>
  </div>
	  
  <!----Note : CSS design for div #signUpBox is in login.css page ------------>
  <div id="signUpBox">
    <h3 style="color: red">Sign up for new account</h3><br><hr><br>
     <form action="signupValidation.php" method="post" name="signUpForm" onsubmit="signUpValidate()">
       <table class="signUpTable">
        <tr>
         <td>First Name:</td>
         <td><input type="text" name="fname" class="inptField" maxlength="40" required></td>
		</tr>
		<tr>
		 <td>Last Name:</td>  
         <td><input type="text" name="lname" class="inptField" maxlength="40" required></td>
		</tr>
		<tr>
		 <td>Mobile No:</td>  
         <td><input type="number" name="mobileNo" class="inptField" required></td>
		</tr>
		<tr>
		 <td>Email:</td>  
		 <td><input type="email" name="email" class="inptField" maxlength="50" required></td>
		</tr>
		<tr>
		 <td>Password:</td>  
		 <td><input type="password" name="pass" class="inptField" maxlength="25" required></td>
		</tr>
		<tr>
		 <td>Retype Password:</td>  
		 <td><input type="password" name="retPass" class="inptField" maxlength="25" required></td>
		</tr>
		 
		<tr>
		 <td></td>
		 <td><input type="submit" name="signupSubmit" value="Sign Up" id="submitButton"></td>
		</tr>
	   </table>
		 
		<table class="signUpTable">
		<tr>
		 <td>Gender:</td>  
		 <td><input type="radio" name="gender" value="Male" id="gender" required>Male           &nbsp;
             <input type="radio" name="gender" value="Female">Female
		 </td>
		</tr> 
		<tr>
		 <td>Address:</td> 
		 <td><textarea name="addr" id="addr" rows="3" maxlength="200" required></textarea></td>
		</tr>
		<tr>
		 <td>City:</td> 
		 <td><input type="text" name="city" class="inptField" maxlength="30" required></td>
		</tr>
		<tr>
		 <td>Pincode:</td>  
         <td><input type="number" name="pinCode" class="inptField" required></td>
		</tr>
	   </table>  
	  </form>
	 </div>
	  
 </div>
  
 </body>
</html>
 
<?php
  }
?> 
 