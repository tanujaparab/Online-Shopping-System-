<?php
  session_start();
  if(!isset($_SESSION["userId"])) {
	session_destroy();
	header("location:index.php");   
  } else {
	
?>

<!DOCTYPE html>
<html>
 <head>
  <title>
	 Shop Online - Home
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" type="text/css" href="css/placeOrder.css">
 </head>

 <body>
   <div id="wrapper">
    <div id="header">
      <div id="logo">
	   <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/>
       </a>
      </div>
	</div>
		 
	 <?php
		 $dateToday = date('d-m-Y');   //Today's date 
		 $deliveryDate = date('d-m-Y', strtotime($dateToday. ' + 5 days')); 
			              //delivery date 
	     $custId = $_SESSION["userId"];
	     $orderAmount = $_SESSION["ttlAmount"];
	  
		 $con = mysqli_connect("localhost","root","","onlineshopping") or           die(mysqli_connect_error());
	  
		 $qry3 = mysqli_query($con,"select cartProducts, cartQtys from customers where               custId='$custId'");
		 $res3 = mysqli_fetch_row($qry3);
		 $cartProducts = $res3[0];
		 $cartQtys = $res3[1];
			 
		 $orderQry = mysqli_query($con, "insert into orders (orderDate, expDeliveryDate, productIds, custId, orderAmount, quantity,payMode) values ('$dateToday','$deliveryDate','$cartProducts','$custId','$orderAmount',
			  '$cartQtys','cod')");
	  
	  	 $deleteProQry = mysqli_query($con, "update customers set cartProducts='0',cartQtys='0' where custId='$custId'");
	     
	  	 header("location:orderPlaced.php");
	 ?>   
  </div>
 </body>
</html>

<?php
  }
?>
