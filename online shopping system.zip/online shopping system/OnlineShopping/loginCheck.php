<?php
 session_start();
 if(isset($_SESSION["userId"])) {
	  header("location:placeOrder.php"); 
  } else {
	  session_destroy();
	  header("location:login.php?loginStatus=forCheckout");
  }  
?>