<!DOCTYPE html>
<html>
 <head>
  <title>
	 Shop Online - Home
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" type="text/css" href="css/login.css"> 
 </head>
	
  <body>
   <div id="wrapper">
	 <div id="header">
        <div id="logo">
	     <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/></a> 
        </div>
     </div>
		
	  
	   
	</div>
  </body>
</html>