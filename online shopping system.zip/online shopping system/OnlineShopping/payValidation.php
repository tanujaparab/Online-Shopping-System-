<?php
  session_start();
  if(!isset($_SESSION["userId"])) {
	session_destroy();
	header("location:index.php");   
  } else {
	
?>

<!DOCTYPE html>
<html>
 <head>
  <title>
	 Shop Online - Home
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" type="text/css" href="css/placeOrder.css">
 </head>

 <body>
   <div id="wrapper">
    <div id="header">
      <div id="logo">
	   <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/>
       </a>
      </div>
	</div>
	   
    <?php
	  	if(isset($_POST['placeOrderButton'])) {
		  $custId = $_SESSION["userId"];
		  $passInpt = $_POST['bankpass'];
         
		 $con = mysqli_connect("localhost","root","","onlineshopping") or           die(mysqli_connect_error());
		 $bnkQry2 = mysqli_query($con,"select * from bankaccount where    
			           custId='$custId'");
		 $payRes2 = mysqli_fetch_row($bnkQry2);
		 $pass = $payRes2[6];
		 
		 if($passInpt == $pass) {
			$dateToday = date('d-m-Y');   //Today's date 
			$deliveryDate = date('d-m-Y', strtotime($dateToday. ' + 5 days')); 
			              //delivery date 
			 
			$orderAmount = $_SESSION["ttlAmount"]; //Order Amount
		    $balance = $payRes2[7]; 
			
		   if($orderAmount <= $balance) {
			$qry3 = mysqli_query($con,"select cartProducts, cartQtys from customers where               custId='$custId'");
			$res3 = mysqli_fetch_row($qry3);
			$cartProducts = $res3[0];
		    $cartQtys = $res3[1];
			 
			 $orderQry = mysqli_query($con, "insert into orders (orderDate, expDeliveryDate, productIds, custId, orderAmount, quantity,payMode) values ('$dateToday','$deliveryDate','$cartProducts','$custId','$orderAmount',
			  '$cartQtys','Debit')");
			 
			 $deleteProQry = mysqli_query($con, "update customers set cartProducts='0',cartQtys='0' where custId='$custId'");
			  
			 $newBalance = $balance - $orderAmount;
			 $balanceUpdate = mysqli_query($con, "update bankaccount set balance=$newBalance where custId='$custId'");
			
			 header("location:orderPlaced.php");
			   
			} else {
		      echo "<div class='payErrorBox'>";
              echo "Insufficient Balance..<br><br>";
			  echo "<a href='mycart.php'>Go to Cart</a>";
		      echo "</div>";
			  mysqli_close($con);
			}  
		 } else {
			echo "<div class='payErrorBox'>";
			 echo "Wrong Bank account Password<br><br>";
			 echo "<a href='placeOrder.php'>Try to Place Order Again</a>";
			echo "</div>";
			mysqli_close($con);
		 }
		 
	}
	   
      if(isset($_POST['paySubmitDebit'])) {
	    $inptCardNum = $_POST['cardNumber'];
	    $inptCvv = $_POST['cvv'];
	  
        $custId = $_SESSION["userId"];
	    $totalAmount = $_SESSION["ttlAmount"];
	
	    $con = mysqli_connect("localhost","root","","onlineshopping") or         die(mysqli_connect_error());
        $bnkQry = mysqli_query($con,"select * from bankaccount where    
			           custId='$custId'");
	    $rows = mysqli_num_rows($bnkQry);
	    if($rows <= 0) {
		   echo "<div class='payErrorBox'>";
           echo "No such Account available<br><br>";
		   echo "<a href='placeOrder.php'>Try Place Order Again</a>";
		   echo "</div>";
        } else {
            $payRes = mysqli_fetch_row($bnkQry);
            $cardNum = $payRes[4];
            $cvv = $payRes[5];
		    if($inptCardNum == $cardNum && $inptCvv == $cvv) {
               echo "<div id='passCheck'>";
				 echo "<form method='post' action=''>";
				 echo "<input type='password' name='bankpass' class='passInpt' placeholder='password'>";
				 echo "<input type='submit' name='placeOrderButton' class='passInpt' value='Pay and Place Order'>";
			     echo "</form>";
			   echo "</div>";
		    } else {
		      echo "<div class='payErrorBox'>";
              echo "Wrong debit card or cvv<br><br>";
			  echo "<a href='placeOrder.php'>Try Place Order Again</a>";
		      echo "</div>";
			  mysqli_close($con);
            }
	    }
      }

    ?>
   </div>
 </body>
</html>

<?php
  }
?>















