<!DOCTYPE html>
<html>
 <head>
  <title>
	 Indian Books
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css">   
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content------=--------------->
	  
	  <?php  include("header2.php");  
	  
	  /* following three header lines are used to reload the page
		   while everytime user hit back button in browser*/
	    include("cacheHeader2.php");
	  ?>
	  
	<!---------------Product Categories------=--------------->
		
	  <?php  include("productCategoryBox2.php");  ?>
	  
	  <?php		
		function showProduct($startNum,$noOfRows) {
		   $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());;
			
		   $qry = mysqli_query($con,"select productId, productName, productPrize, image from books where bookCategory='Indian' LIMIT $startNum,$noOfRows"); 

		   while($res = mysqli_fetch_row($qry)) {
              $proId = $res[0];
	          $proName = $res[1]; 
              $proPrize = $res[2];
              $proImg = $res[3];
			   
		   echo "<td class='productBox'>";
		   echo "<a href='viewProduct.php?proId=$proId'>";
			echo "<span class='tdBody'>";
			 echo "<img src='../$proImg' width='100' height='200'/><br>";
			 echo $proName."<br>";
			 echo "<span class='proPrize'>";
			   echo  "Prize: &#8377;".$proPrize."<br>"; 
			 echo "</span>";
			echo "</span> ";
		   echo "</a>";  
		   echo "</td>";  
			  
		   }		
		}
	  ?>
	  
	  <div id="productTable">
		<table>
		 <tr>
		  <th colspan="3" class="tHead">Indian Books</th>	
		 </tr>
	     <tr>
		   <?php showProduct(0,3); ?> 
		 </tr>
		 <tr>
		   <?php showProduct(3,3); ?> 
		 </tr>
		</table>
	  </div>
	  
  </div>
	 
 </body>
</html>