<!DOCTYPE html>
<html>
 <head>
  <title>
	 Mobile Phones
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css">   
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content------=--------------->
	  
	  <?php  include("header2.php");  
		
		/* following three header lines are used to reload the page
		   while everytime user hit back button in browser*/
	    include("cacheHeader2.php");
	  ?>
	  
	<!---------------Product Categories------=--------------->
		
	  <?php  include("productCategoryBox2.php");  ?>
	  
	  <?php		
		function showProduct($proId) {
		   $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());;
			
		   $qry = mysqli_query($con,"select productName, productPrize, image from mobiles where productId='$proId'"); 
		   $res = mysqli_fetch_row($qry);
	       $proName = $res[0]; 
           $proPrize = $res[1];
           $proImg = $res[2];
			
		   echo "<a href='viewProduct.php?proId=$proId'>";
			echo "<span class='tdBody'>";
			 echo "<img src='../$proImg' width='65' height='130'/><br>";
			 echo $proName."<br>";
			 echo "<span class='proPrize'>";
			   echo  "Prize: &#8377;".$proPrize."<br>"; 
			 echo "</span>";
			echo "</span> ";
		   echo "</a>"; 
		}
	  ?>
	  
	 <div id="productTable">
		<table>
		 <tr>
		  <td colspan="4" class="tHead">Mobile Phones</td>	
		 </tr>
	     <tr>
		  <td class="productBox"> <?php showProduct(10101); ?> </td> 
		  <td class="productBox"> <?php showProduct(10102); ?> </td>
		  <td class="productBox"> <?php showProduct(10103); ?> </td>
		  <td class="productBox"> <?php showProduct(10104); ?> </td>
		 </tr>
		 <tr>
		  <td class="productBox"> <?php showProduct(10105); ?> </td> 
		  <td class="productBox"> <?php showProduct(10106); ?> </td>
		  <td class="productBox"> <?php showProduct(10107); ?> </td>
		  <td class="productBox"> <?php showProduct(10108); ?> </td>
		 </tr>
		 <tr>
		  <td class="productBox"> <?php showProduct(10109); ?> </td> 
		  <td class="productBox"> <?php showProduct(10110); ?> </td>
		  <td class="productBox"> <?php showProduct(10111); ?> </td>
		  <td class="productBox"> <?php showProduct(10112); ?> </td>
	     </tr>
			
		 <tr>
		  <td class="productBox"> <?php showProduct(10113); ?> </td> 
		  <td class="productBox"> <?php showProduct(10114); ?> </td>
		 </tr>
	    </table>
	  </div>
	  
  </div>
	 
 </body>
</html>