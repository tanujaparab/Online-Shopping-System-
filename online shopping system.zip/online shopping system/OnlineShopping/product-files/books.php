<!DOCTYPE html>
<html>
 <head>
  <title>
	 Books
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css">   
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content------=--------------->
	  
	  <?php  include("header2.php");  ?>
	  
	<!---------------Product Categories------=--------------->
		
	  <?php  include("productCategoryBox2.php");  ?>
	  
	  <?php		
		function showProduct($proId) {
		   $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());;
			
		   $qry = mysqli_query($con,"select bookTitle, bookPrize, image from books where productId='$proId'"); 
		   $res = mysqli_fetch_row($qry);
	       $proName = $res[0]; 
           $proPrize = $res[1];
           $proImg = $res[2];
			
		   echo "<a href='viewProduct.php?proId=$proId'>";
			echo "<span class='tdBody'>";
			 echo "<img src='../$proImg' width='65' height='130'/><br>";
			 echo $proName."<br>";
			 echo "<span class='proPrize'>";
			   echo  "Prize: &#8377;".$proPrize."<br>"; 
			 echo "</span>";
			echo "</span> ";
		   echo "</a>"; 
		}
	  ?>
	  
	  <div id="productTable">
		<table>
		 <tr>
		  <td colspan="4" class="tHead">Books</td>	
		 </tr>
	     <tr>
		  
		 </tr>
		</table>
	  </div>
  </div>
	 
 </body>
</html>