
<!DOCTYPE html>
<html>
 <head>
  <title>
	 Product Page
  </title>
  <meta http-equiv="PRAGMA" content="NO-CACHE"> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script type="text/javascript">
	 
  </script>
  <link rel="stylesheet" type="text/css" href="../css/index.css">  
  <link rel="stylesheet" type="text/css" href="../css/viewProduct.css">	 
 </head>
	
  <body>
	<div id="wrapper">
	  <!---------------Header Content---------------------->
	  
	  <?php  include("header2.php");  
		
		/* following three header lines are used to reload the page
		   while everytime user hit back button in browser*/
	    include("cacheHeader2.php");
	   ?>
		
	  <!---------------Product Categories--------------------->
		
	  <?php  include("productCategoryBox2.php");  ?>
		
	  <?php
		//----------function to show all product details-----------//
		
		function checkFields($proId) {
		  if($proId >= 10101 && $proId <= 20100) {
			$fields = array("Brand Name","Color","RAM","ROM","Display","Camera",
            "Battery","Operating System","Seller","Weight","Product Description");
		  } else if($proId >= 20101 && $proId <= 25100) {
			$fields = array("Brand Name","Category","Seller","Color","Size","Fit","Sleeve",
             "Pattern","Fabric","Neck Type","Stretchable","Closure","rise");  
		  } else if($proId >= 25101 && $proId <= 30100) {
			$fields = array("Brand Name","Category","Seller","Color","Size","Blouse  Piece","saree Length","Pattern","Fabric","Neck Type","length","sleeve","Other Details");  
		  } else if($proId >= 30101 && $proId <= 35100) {
			$fields = array("Brand Name","Category","Seller","Primary Color","Secondary Color","Size","Type","Sleeve","Pattern","Fabric","ocassion");  
		  } else if($proId >= 35101 && $proId <= 40100) {
			$fields = array("Brand Name","Category","Seller","Color","Size","Neck Type","Ideal For","Fit","Sleeve","Pattern","Fabric","Closure","Pockets");  
		  } else if($proId >= 40101 && $proId <= 50100) {
			$fields = array("Brand Name","Seller","Water Resistant","Display   Type","Diameter","Thickness","Material","Warranty");  
		  } else if($proId >= 50101 && $proId <= 60100) {
			$fields =array("Category","ISBN","Author","Publication","Language","Binding",
            "Seller","Description");  
		  }
			return $fields;
		}
		
	    error_reporting(E_ALL & ~E_NOTICE);
		$con = mysqli_connect("localhost","root","","onlineshopping") or        
		 die(mysqli_connect_error());
		
		$proId = $_REQUEST['proId'];
		if($proId == "") {
			echo "Go to Home page";
		} else if($proId >= 10101 && $proId <= 20100){
			$sql = "select * from mobiles where productId='$proId'";
			$qry = mysqli_query($con,$sql);
			if(mysqli_num_rows($qry) > 0) {
		        showProductDetails($sql);			
			} else {
			   echo "Go to Home page";
			}
		} else if($proId >= 20101 && $proId <= 25100) {
			$sql = "select * from menswear where productId='$proId'";
			$qry = mysqli_query($con,$sql);
			if(mysqli_num_rows($qry) > 0) {
		        showProductDetails($sql);			
			} else {
			   echo "Go to Home page";
			}
		} else if($proId >= 25101 && $proId <= 30100) {
			$sql = "select * from ladieswear where productId='$proId'";
			$qry = mysqli_query($con,$sql);
			if(mysqli_num_rows($qry) > 0) {
		        showProductDetails($sql);			
			} else {
			   echo "Go to Home page";
			}
		} else if($proId >= 30101 && $proId <= 35100) {
			$sql = "select * from childrenswear where productId='$proId'";
			$qry = mysqli_query($con,$sql);
			if(mysqli_num_rows($qry) > 0) {
		        showProductDetails($sql);			
			} else {
			   echo "Go to Home page";
			}
		} else if($proId >= 35101 && $proId <= 40100) {
			$sql = "select * from sportswear where productId='$proId'";
			$qry = mysqli_query($con,$sql);
			if(mysqli_num_rows($qry) > 0) {
		        showProductDetails($sql);			
			} else {
			   echo "Go to Home page";
			}
		} else if($proId >= 40101 && $proId <= 50100) {
			$sql = "select * from watches where productId='$proId'";
			$qry = mysqli_query($con,$sql);
			if(mysqli_num_rows($qry) > 0) {
		        showProductDetails($sql);			
			} else {
			   echo "Go to Home page";
			}
		} else if($proId >= 50101 && $proId <= 60100) {
			$sql = "select * from books where productId='$proId'";
			$qry = mysqli_query($con,$sql);
			if(mysqli_num_rows($qry) > 0) {
		        showProductDetails($sql);			
			} else {
			   echo "Go to Home page";
			}
		} else {
			 echo "Go to Home page";
		}
		
		function showProductDetails($sql) {
		   $con = mysqli_connect("localhost","root","","onlineshopping") or        
		    die(mysqli_connect_error());
			
			$qry = mysqli_query($con,$sql);
			$res = mysqli_fetch_row($qry);
            $image = $res[3];
			$avail = $res[15];
			
		 echo "<div id='productDetailsBox'>";
			echo "<div id='proImage'>";
			 echo "<img src='../$image' width='200' height='400'>";
			echo "</div>";
			
			echo "<div id='proFeatures'>";
			 echo "<div id='productName'> $res[1] </div><br>";
			 echo "<div id='productPrize'>Prize: &#8377; $res[2]/-</div><br>";
			
			 echo "<h4 id='FeatureHead'>Features:</h4>";
			
			$fields = checkFields($res[0]);
			$fieldIndex = 0;
            $resultIndex = 4;
			
			$count = count($res); 
			echo "<table id='featuresTable'>";
			while($resultIndex <= $count-2) {
				echo "<tr>";
				if($res[$resultIndex] != "") {
				   echo "<td id='featureName'>".$fields[$fieldIndex]."</td><td>".$res[$resultIndex]."</td>";
	               $resultIndex++;
	               $fieldIndex++;
				} else {
				   $resultIndex++;
	               $fieldIndex++;
				}
				echo "</tr>";
            } 
			echo "</table>";
			echo "</div>";
		   
			echo "<div id='addCartBox'>";
			  $soldQry= mysqli_query($con,$sql);
			  $soldRes = mysqli_fetch_assoc($soldQry);
			  $avaiItems = $soldRes["availableItems"];
			 
			  if($avaiItems == 0) {
				  echo "<a href=''>
					 <button id='addButtonDisabled'>Sold Out</button></a><br><br>";
				    echo "<script>";
                     echo "document.getElementById('addButtonDisabled').disabled = true";
                    echo "</script>";
			  } else if(isset($_SESSION["userId"])) {
				  $custId = $_SESSION["userId"];
	  
	              $qry2 = mysqli_query($con,"select * from customers where custId='$custId'");
	              $res2 = mysqli_fetch_array($qry2);
	              $accCartItems = $res2["cartProducts"];
				  
	              if($accCartItems == '0' || $accCartItems == '') {
                     echo "<a href='../addToCart.php?proId=$res[0]'><button     
				        id='addCartButton'> Add to Cart</button></a><br><br>";
				  } else {
					 $productArray = explode('_',$accCartItems); 
					 if(in_array($res[0],$productArray)) {
				       echo "<a href='../addToCart.php?proId=$res[0]'>
					   <button id='addButtonDisabled'>Add to Cart</button></a><br>";
				      echo "<span id='added'>Already added to cart</span><br><br>";
				       echo "<script>";
                       echo "document.getElementById('addButtonDisabled').disabled = true";
                      echo "</script>"; 
					 } else {
						echo "<a href='../addToCart.php?proId=$res[0]'><button     
				        id='addCartButton'> Add to Cart</button></a><br><br>"; 
					 }
				  }  
				  
			 } else {
				  $cartItems = $_COOKIE['cartItems'];
			     if($cartItems == '0' || $cartItems == '')
                 {
                  echo "<a href='../addToCart.php?proId=$res[0]'><button     
				        id='addCartButton'> Add to Cart</button></a><br><br>";
                 } else {
				  $productArray = explode('_',$cartItems);
				  
                  if(in_array($res[0],$productArray)) {
				     echo "<a href='../addToCart.php?proId=$res[0]'>
					 <button id='addButtonDisabled'>Add to Cart</button></a><br>";
				    echo "<span id='added'>Already added to cart</span><br><br>";
				     echo "<script>";
                     echo "document.getElementById('addButtonDisabled').disabled = true";
                    echo "</script>"; 
				 } else {
					 echo "<a href='../addToCart.php?proId=$res[0]'><button id='addCartButton'>
			          Add to Cart</button></a><br><br>"; 
				 }
			  }
			}
			
			//  echo "<button id='buyNowButton'>Buy Now</button>";
			echo "</div>";
		//  echo "</div";
			
		}
	  ?>
		
		
    </div>
	  
  </body>
</html>