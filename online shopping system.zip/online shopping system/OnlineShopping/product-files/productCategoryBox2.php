<div id="productCategoryBox">
        <div id="categoryHeader">
	      Categories
	    </div>	
	
		<div id="Mobiles">
		<span class="categoryName"><a href="mobiles.php">Mobiles</a><br><hr></span>
		  <ul>
		   <li><a href="apple.php">Apple</a></li>
		   <li><a href="samsung.php">Samsung</a></li>
		   <li><a href="xiomi.php">Xiomi</a></li>
		   <li><a href="vivo.php">Vivo</a></li>
		  </ul>
        </div>
		  
		<div id="Clothing">
		<span class="categoryName"><a href="clothing.php">Clothing</a><br><hr></span>
		 <ul>
		   <li><a href="mensWear.php">Mens Wear</a></li>
		   <li><a href="ladiesWear.php">Ladies Wear</a></li>
		   <li><a href="childrensWear.php">Childrens Wear</a></li>
		   <li><a href="sportsWear.php">Sports Wear</a></li>
		  </ul>
        </div>
		  
		<div id="Watches">
		<span class="categoryName"><a href="watches.php">Watches</a><br><hr></span>
		 <ul>
		   <li><a href="fastrack.php">Fastrack</a></li>
		   <li><a href="casio.php">Casio</a></li>
		   <li><a href="titan.php">Titan</a></li>
		   <li><a href="fossil.php">Fossil</a></li>
		  </ul>
        </div>
		  
		<div id="Books">
		<span class="categoryName"><a href="books.php">Books</a><br><hr></span>
		 <ul>
		   <li><a href="bestsellers.php">Bestsellers</a></li>
		   <li><a href="indianBooks.php">Indian</a></li>
		   <li><a href="autobiography.php">Autobiography</a></li>
		   <li><a href="academic.php">Academic</a></li>
		  </ul>
        </div> 
	  </div>