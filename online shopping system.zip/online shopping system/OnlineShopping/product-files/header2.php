<div id="header">
  <div id="logo">
	 <a href="../index.php"><img src="../images/cartmagic_logo.png" width="275" height="70"/>
     </a>
  </div>
	
  <div id="rightHeaderBox">
	<a href="../myCart.php">
     <div id="cartBox"><img src="../images/emptyCartLight.png" width="36" height="36" 
                        align="middle"/>
	   <span id="cartText">
		 Cart 
		 <span id="cartCount">
         <?php
            session_start();
		    if(isset($_SESSION['userId'])) {
				$custId = $_SESSION["userId"] ;
				
				$con = mysqli_connect("localhost","root","","onlineshopping") or        
	                    die(mysqli_connect_error());
				$qry = mysqli_query($con,"select * from customers where  
				       custId='$custId'");
		        $res = mysqli_fetch_array($qry);
		        $accCartItems = $res["cartProducts"];
				$productArray = explode("_",$accCartItems);
				$noOfProducts = count($productArray);
                $noOfProducts = --$noOfProducts;
				echo $noOfProducts;
				mysqli_close($con);
			} else {			   
		       if(isset($_COOKIE['cartItems'])) {
			     $cartItems = $_COOKIE['cartItems'];
			     $productArray = explode("_",$cartItems);
                 $noOfProducts = count($productArray);
                 $noOfProducts = --$noOfProducts;
			     echo $noOfProducts;
               } else {
                  echo "0";
               }
			}
         ?>
          </span>
	   </span>
      </div>
	 </a>
	   
	 <?php 
		   if(isset($_SESSION['userId'])) {
			   $custId = $_SESSION['userId'];
               $fname = $_SESSION['firstName'];
               echo "<div id='userName'>";
               echo $fname;
               echo "</div>";
			   
			   echo "<a href='../signOut.php'><input type='button' value='Sign Out' id='signOut'></a>";
		   } else {
			   
		   
	       ?>
	   
	        <a href="../login.php">
		      <div id="loginButton">
		        Login
		      </div>
	        </a>
	   
	        <a href="../signup.php">
              <div id="signUpButton">
                Sign Up 
              </div>
	        </a>
	   <?php
			 session_destroy();
		     }
	   ?>
  </div>
	
  <div id="searchBar">
    <input type="text" id="searchBox" placeholder="Search products..."                        name="searchProduct">
	<button id="searchButton"><img src="../images/searchIcon.png" width="19" height="19">
	</button>
  </div>
</div>

