<!DOCTYPE html>
<html>
 <head>
  <title>
	 Clothing
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css">   
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content------=--------------->
	  
	  <?php  include("header2.php");  ?>
	  
	<!---------------Product Categories------=--------------->
		
	  <?php  include("productCategoryBox2.php");  ?>
	  
  </div>
	 
 </body>
</html>