<?php
 session_start();
  if(!isset($_SESSION["userId"])) {
	session_destroy();
	header("location:index.php");   
  } else {
	
?>

<!DOCTYPE html>
<html>
 <head>
  <title>
	 Order Placed
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" type="text/css" href="css/placeOrder.css">
	 
    <script type="text/javascript">
         function disablePrev() { window.history.forward() }
         window.onload = disablePrev();
         window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    </script>
 </head>

  <body>
   <div id="wrapper">
    <div id="header">
      <div id="logo">
	   <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/>
       </a>
      </div>
	</div>
	   
	<div class='orderPlacedBox'>
	  Your order has been placed Successfully..
	</div>
   </div>
 </body>
</html>

<?php
  }
?>