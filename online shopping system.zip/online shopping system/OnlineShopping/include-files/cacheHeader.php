<?php
/* following three header lines are used to reload the page
		   while everytime user hit back button in browser */

		header("Cache-Control: no-store, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
?>