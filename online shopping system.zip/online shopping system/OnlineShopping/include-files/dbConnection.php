<?php
	$con = mysqli_connect("localhost","root","","onlineshopping") or        
	  die(mysqli_connect_error());
?>