<div id="productCategoryBox">
	    <div id="categoryHeader">
	      Categories
	    </div>
	
		<div id="Mobiles">
		<span class="categoryName"><a href="product-files/mobiles.php">Mobiles</a><br><hr></span>
		  <ul>
		   <li><a href="product-files/apple.php">Apple</a></li>
		   <li><a href="product-files/samsung.php">Samsung</a></li>
		   <li><a href="product-files/xiomi.php">Xiomi</a></li>
		   <li><a href="product-files/vivo.php">Vivo</a></li>
		  </ul>
        </div>
		  
		<div id="Clothing">
		<span class="categoryName"><a href="product-files/clothing.php">Clothing</a><br><hr></span>
		 <ul>
		   <li><a href="product-files/mensWear.php">Mens Wear</a></li>
		   <li><a href="product-files/ladiesWear.php">Ladies Wear</a></li>
		   <li><a href="product-files/childrensWear.php">Childrens Wear</a></li>
		   <li><a href="product-files/sportsWear.php">Sports Wear</a></li>
		  </ul>
        </div>
		  
		<div id="Watches">
		<span class="categoryName"><a href="product-files/watches.php">Watches</a><br><hr></span>
		 <ul>
		   <li><a href="product-files/fastrack.php">Fastrack</a></li>
		   <li><a href="product-files/casio.php">Casio</a></li>
		   <li><a href="product-files/titan.php">Titan</a></li>
		   <li><a href="product-files/fossil.php">Fossil</a></li>
		  </ul>
        </div>
		  
		<div id="Books">
		<span class="categoryName"><a href="product-files/books.php">Books</a><br><hr></span>
		 <ul>
		   <li><a href="product-files/bestsellers.php">Bestsellers</a></li>
		   <li><a href="product-files/indianBooks.php">Indian</a></li>
		   <li><a href="product-files/autobiography.php">Autobiography</a></li>
		   <li><a href="product-files/academic.php">Academic</a></li>
		  </ul>
        </div> 
	  </div>