<!DOCTYPE html>
<html>
 <head>
  <title>
	Add Watch Product
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css"> 
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="../css/login.css">
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content---------------------->
	  
 <div id="header">
  <div id="logo">
	 <img src="../images/cartmagic_logo.png" width="275" height="70"/>
  </div>
	 
  <div id="adminHome">
	<a href="admin_index.php">Admin Home</a>
  </div>
 </div>
	  
 <div id="addProductBox">
   <h3 style="color: red">Add Watch Product</h3><br><hr><br>
   <form action="" method="post" enctype="multipart/form-data">
	 <table class="addTableContent">
	  <tr>
	   <td>Product Name: </td>
	   <td><input type="text" name="ProductName" class="inptField" maxlength="50" required></td> 
	  </tr>
	  <tr>
		  <td>Prize: </td>
		  <td><input type="number" name="proPrize" class="inptField" max="1000000" required></td>
	  </tr> 
	  <tr>
		  <td>Choose Image: </td>  
		  <td><input type="file" name="image" required></td> 
	  </tr>
	  <tr>
		  <td>Brand Name: </td>
		  <td><input type="text" name="brandName" class="inptField" maxlength="50" required></td> 
	  </tr>
	  <tr>
		  <td>Clothing Category: </td>
		  <td><select name="ClothCategory" required>
			    <option value="">Select Category</option>
                <option value="Shirt">Shirt</option>
                <option value="Jeans">Jeans</option>
                <option value="T-shirt">T-shirt</option>
              </select>
		  </td>  
	  </tr>
	   <tr>
		   <td>Seller: </td>
		   <td><input type="text" name="seller" class="inptField" maxlength="40" required></td>
	   </tr>
	   <tr>
		  <td>Color: </td>
		  <td><input type="text" name="proColor" class="inptField" maxlength="25" required></td>  
	  </tr>
	  <tr>
		  <td>Size: </td>
		  <td><input type="text" name="size" class="inptField" maxlength="10" required></td> 
	  </tr>
       <tr>   
		   <td>Fit : </td>
		   <td><input type="text" name="fit" class="inptField" maxlength="20"></td>
	   </tr>
      <tr>
       <td></td>
       <td><input type="submit" name="submit" value="Add Product" id="submitButton"></td>
      </tr>
     </table>
	   
	 <table class="addTableContent">
	   <tr>
		   <td>Sleeve: </td>
		   <td><input type="text" name="sleeve" class="inptField" maxlength="20"></td>
	   </tr>
	   <tr>
		   <td>Pattern: </td>
		   <td><input type="text" name="pattern" class="inptField" maxlength="25"></td>
	   </tr>
	   <tr>
		   <td>Fabric: </td>
		   <td><input type="text" name="fabric" class="inptField" maxlength="25" required></td>
	   </tr>
	   <tr>
		   <td>Neck Type: </td>
		   <td><input type="text" name="neckType" class="inptField" maxlength="25"></td>
	   </tr>
       <tr>
		   <td>Stretchable: </td>
		   <td><input type="text" name="stretchable" class="inptField" maxlength="5"></td>
	   </tr>
       <tr>
		   <td>Closure: </td>
		   <td><input type="text" name="closure" class="inptField" maxlength="20"></td>
	   </tr>
       <tr>
		   <td>Rise: </td>
		   <td><input type="text" name="rise" class="inptField" maxlength="20"></td>
	   </tr>
	   <tr>
	    <td>Availability: </td>
	    <td><input type="text" name="availItems" class="inptField" max="999" required></td>
	   </tr>
	 </table>
   </form>
  </div>
	  
  <?php 
	if(isset($_POST['submit'])) {
		$con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
		
		//---------- Mobile Details----------------		
		$productName = $_POST['ProductName'];
		$proPrize = $_POST['proPrize'];
		$brandName = $_POST['brandName'];
		$clothCategory = $_POST['ClothCategory'];
        $seller = $_POST['seller'];
        $proColor = $_POST['proColor'];
		$size = $_POST['size'];
		$fit = $_POST['fit'];
		$sleeve = $_POST['sleeve'];
		$pattern = $_POST['pattern'];
		$fabric = $_POST['fabric'];
		$neckType = $_POST['neckType'];

		$stretchable = $_POST['stretchable'];
		$closure = $_POST['closure'];
		$rise = $_POST['rise'];
		$availItems = $_POST['availItems'];
		
		//--------- upload image details-----------
		$imageName = $_FILES['image']['name'];
		$imageType = $_FILES['image']['type'];
		$tmpName = $_FILES['image']['tmp_name'];
		$location = "../images/Clothing/";
		
		if($imageType == "image/jpeg" || $imageType == "image/jpg" || $imageType == "image/gif" || $imageType == "image/png" ) {
			if(move_uploaded_file($tmpName, $location.$imageName)) {
				if($sql = mysqli_query($con,"insert into menswear (productName, productPrize, image, brandName, clothingCategory, seller,color, size, fit, sleeve, pattern, fabric, neckType, stretchable, closure, rise, availableItems) values ('$productName','$proPrize','images/Clothing/$imageName','$brandName',
                 '$clothCategory','$seller','$proColor','$size','$fit',
				 '$sleeve','$pattern','$fabric','$neckType','$stretchable',
				 '$closure','$rise','$availItems')")) {
	                  echo "Product Inserted SuccessFully";
                 } else {
	                 echo "Databse Error";
                 }
			} else {
				echo "Failed to upload..>";
			}
		} else {
			echo "Sorry, This file type is not allowed.";
		}

		
	}  
  ?>
 </div>
  
 </body>
</html>
 