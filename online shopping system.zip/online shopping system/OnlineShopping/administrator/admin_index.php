<!DOCTYPE html>
<html>
 <head>
  <title>
	Admin Login
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css"> 
  <link rel="stylesheet" type="text/css" href="admin.css">
  
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content---------------------->
	  
 <div id="header">
  <div id="logo">
	 <a href="../index.php"><img src="../images/cartmagic_logo.png" width="275" height="70"/></a>
  </div>
  <div>
  <a href='LogOut.php'><input type='button' value='Log Out' id='LogOut'></a>
  
  </div>
 </div>
	  
 <div id="buttonBox">
	<a href="addProduct.php"><button class="btn">Add Product</button></a><br><br>
	<a href="removeProduct.php"><button class="btn">Remove Product</button></a><br><br>
 </div>
	  
 </div>
  
 </body>
</html>
 