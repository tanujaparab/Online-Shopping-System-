<!DOCTYPE html>
<html>
 <head>
  <title>
	Remove Product
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css"> 
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="../css/login.css">
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content---------------------->
	  
 <div id="header">
  <div id="logo">
	 <img src="../images/cartmagic_logo.png" width="275" height="70"/>
  </div>
	 
  <div id="adminHome">
	<a href="admin_index.php">Admin Home</a>
  </div>
 </div>
	  
 <div id="removeProductBox">
   <h3 style="color: red">Remove a Product</h3><br><hr><br>
   <span>Enter product ID to be removed : </span>
   <form action="#" method="post" id="removeForm">
	 <input type="number" name="productId" class="inptField" max="100000" required><br>
	 <input type="submit" value="Remove" name="removeButton" id="submitButton">
   </form><br><br>
   <?php 
	if(isset($_POST['removeButton'])) {
		$con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
		
		$productId = $_POST['productId'];
		if($productId >= 10101 && $productId <= 20100) {
		  $qry = mysqli_query($con,"select * from mobiles where productId='$productId'"); 
		  $rowCount = mysqli_num_rows($qry);
		  if($rowCount > 0) {
		   $qry = mysqli_query($con,"delete from mobiles where           
		     productId='$productId'"); 
		   echo "Product Removed Successfully..";
		  } else {
			   echo "No such Product Id available..";
		  }  
		} else if($productId >= 20101 && $productId <= 25100) {
		  $qry = mysqli_query($con,"select * from menswear where 
		               productId='$productId'"); 
		   $rowCount = mysqli_num_rows($qry);
		   if($rowCount > 0) {
			$qry = mysqli_query($con,"delete from menswear where 
			            productId='$productId'"); 
			echo "Product Removed Successfully..";
		  } else {
			   echo "No such Product Id available..";
		  }
		} else if($productId >= 25101 && $productId <= 30100) {
		  $qry = mysqli_query($con,"select * from ladieswear where 
		                 productId='$productId'"); 
		   $rowCount = mysqli_num_rows($qry);
		   if($rowCount > 0) {
			$qry = mysqli_query($con,"delete from ladieswear where 
			             productId='$productId'"); 
			echo "Product Removed Successfully..";
		  } else {
			   echo "No such Product Id available..";
		  }
		} else if($productId >= 30101 && $productId <= 35100) {
		  $qry = mysqli_query($con,"select * from childrenswear where 
		                 productId='$productId'"); 
		   $rowCount = mysqli_num_rows($qry);
		   if($rowCount > 0) {
			$qry = mysqli_query($con,"delete from childrenswear where 
			             productId='$productId'"); 
			echo "Product Removed Successfully..";
		  } else {
			   echo "No such Product Id available..";
		  }
		} else if($productId >= 35101 && $productId <= 40100) {
		  $qry = mysqli_query($con,"select * from sportswear where 
		                 productId='$productId'"); 
		   $rowCount = mysqli_num_rows($qry);
		   if($rowCount > 0) {
			$qry = mysqli_query($con,"delete from sportswear where 
			             productId='$productId'"); 
			echo "Product Removed Successfully..";
		  } else {
			   echo "No such Product Id available..";
		  }
		} else if($productId >= 40101 && $productId <= 50100) {
		  $qry = mysqli_query($con,"select * from watches where 
		                 productId='$productId'"); 
		   $rowCount = mysqli_num_rows($qry);
		   if($rowCount > 0) {
			$qry = mysqli_query($con,"delete from watches where 
			             productId='$productId'"); 
			echo "Product Removed Successfully..";
		  } else {
			   echo "No such Product Id available..";
		  }
		} else if($productId >= 50101 && $productId <= 60100) {
		  $qry = mysqli_query($con,"select * from books where 
		                 productId='$productId'"); 
		   $rowCount = mysqli_num_rows($qry);
		   if($rowCount > 0) {
			$qry = mysqli_query($con,"delete from books where 
			             productId='$productId'"); 
			echo "Product Removed Successfully..";
		  } else {
			   echo "No such Product Id available..";
		  }
		} else {
			echo "No such Product Id available..";
		}
	} 
   ?>
 </div>
	  
 </div>
  
 </body>
</html>
 