<?php
session_start();

include("include-files2/dbConnection.php");
	
	if(isset($_POST['submit']))
	{
		$email = htmlentities(mysqli_real_escape_string($con, $_POST['email']));
		$pass = htmlentities(mysqli_real_escape_string($con, $_POST['pass']));
		
		$select_admin = "select * from administrator where userId='$email' AND password='$pass'";
		
		$query = mysqli_query($con, $select_admin);
		
		$check_admin = mysqli_num_rows($query);
		
		if ($check_admin ==1)
		{
			$_SESSION['userId'] = $email;
			
			echo "<script>window.open('admin_index.php', '_self')</script>";
		}
		else
		{
			echo "<script>alert('Your UserID or Password is incorrect')</script>";
		}
	}

?>