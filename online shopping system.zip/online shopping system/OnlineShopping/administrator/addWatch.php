<!DOCTYPE html>
<html>
 <head>
  <title>
	Add Watch Product
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css"> 
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="../css/login.css">
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content---------------------->
	  
 <div id="header">
  <div id="logo">
	 <img src="../images/cartmagic_logo.png" width="275" height="70"/>
  </div>
	 
  <div id="adminHome">
	<a href="admin_index.php">Admin Home</a>
  </div>
 </div>
	  
 <div id="addProductBox">
   <h3 style="color: red">Add Watch Product</h3><br><hr><br>
   <form action="" method="post" enctype="multipart/form-data">
	 <table class="addTableContent">
	  <tr>
	   <td>Product Name: </td>
	   <td><input type="text" name="ProductName" class="inptField" maxlength="50" required></td> 
	  </tr>
	  <tr>
		  <td>Prize: </td>
		  <td><input type="number" name="proPrize" class="inptField" max="1000000" required></td>
	  </tr> 
	  <tr>
		  <td>Choose Image: </td>  
		  <td><input type="file" name="image" required></td> 
	  </tr>
	  <tr>
		  <td>Brand Name: </td>
		  <td><input type="text" name="brandName" class="inptField" maxlength="25" required></td> 
	  </tr>
	   <tr>
		   <td>Seller: </td>
		   <td><input type="text" name="seller" class="inptField" maxlength="40" required></td>
	   </tr>
	  <tr>
		  <td>Water Resistant: </td>
		  <td><input type="text" name="waterResistant" class="inptField" maxlength="15"></td> 
	  </tr>
       <tr>   
		   <td>Display Type : </td>
		   <td><input type="text" name="displayType" class="inptField" maxlength="20"></td>
	   </tr>
      <tr>
       <td></td>
       <td><input type="submit" name="submit" value="Add Product" id="submitButton"></td>
      </tr>
     </table>
	   
	 <table class="addTableContent">
	   <tr>
		   <td>Diameter: </td>
		   <td><input type="text" name="diameter" class="inptField" maxlength="15"></td>
	   </tr>
	   <tr>
		   <td>Thickness: </td>
		   <td><input type="text" name="thickness" class="inptField" maxlength="15"></td>
	   </tr>
	   <tr>
		   <td>Material: </td>
		   <td><input type="text" name="material" class="inptField" maxlength="40" required></td>
	   </tr>
	   <tr>
		   <td>Warranty: </td>
		   <td><input type="text" name="warranty" class="inptField" maxlength="20"></td>
	   </tr>
	   <tr>
	    <td>Availability: </td>
	    <td><input type="text" name="availItems" class="inptField" max="999" required></td>
	   </tr>
	 </table>
   </form>
  </div>
	  
  <?php 
	if(isset($_POST['submit'])) {
		$con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
		
		//---------- Mobile Details----------------		
		$productName = $_POST['ProductName'];
		$proPrize = $_POST['proPrize'];
		$brandName = $_POST['brandName'];
        $seller = $_POST['seller'];
        $waterResistant = $_POST['waterResistant'];
		$displayType = $_POST['displayType'];
		$diameter = $_POST['diameter'];
		$thickness = $_POST['thickness'];
		$material = $_POST['material'];
		$warranty = $_POST['warranty'];
		$availItems = $_POST['availItems'];
		
		//--------- upload image details-----------
		$imageName = $_FILES['image']['name'];
		$imageType = $_FILES['image']['type'];
		$tmpName = $_FILES['image']['tmp_name'];
		$location = "../images/Watches/";
		
		if($imageType == "image/jpeg" || $imageType == "image/jpg" || $imageType == "image/gif" || $imageType == "image/png" ) {
			if(move_uploaded_file($tmpName, $location.$imageName)) {
				if($sql = mysqli_query($con,"insert into watches (productName, productPrize, image, brandName, seller, waterResistant, displayType,  diameter, thickness, material, warranty, availableItems) values ('$productName','$proPrize','images/Watches/$imageName','$brandName',
                 '$seller','$waterResistant','$displayType','$diameter',
				 '$thickness','$material','$warranty','$availItems')")) {
	                  echo "Product Inserted SuccessFully";
                 } else {
	                 echo "Databse Error";
                 }
			} else {
				echo "Failed to upload..>";
			}
		} else {
			echo "Sorry, This file type is not allowed.";
		}

		
	}  
  ?>
 </div>
  
 </body>
</html>
 