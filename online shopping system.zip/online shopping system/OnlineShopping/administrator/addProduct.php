<!DOCTYPE html>
<html>
 <head>
  <title>
	Add Product
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css"> 
  <link rel="stylesheet" type="text/css" href="admin.css">
	 
  <script src="jquery-3.3.1.min.js"></script> 
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content---------------------->
	  
 <div id="header">
  <div id="logo">
	 <img src="../images/cartmagic_logo.png" width="275" height="70"/>
  </div>
	 
  <div id="adminHome">
	<a href="admin_index.php">Admin Home</a>
  </div>
 </div>
	  
 <div id="productBtnBox">
	<a href="addMobile.php"><button id="mobileBtn" class="btn">Mobile</button></a><br><br>
	<a href="addMensWear.php"><button id="mensWearBtn" class="btn">Mens Wear</button></a><br><br>
	<a href="addLadiesWear.php"><button id="ladiesWearBtn" class="btn">Ladies Wear</button></a><br><br>
	<a href="addChildrensWear.php"><button id="childrensWearBtn" class="btn">Childrens Wear</button></a><br><br>
	<a href="addSportsWear.php"><button id="sportsWearBtn" class="btn">Sports Wear</button></a><br><br>
	<a href="addWatch.php"><button id="watchBtn" class="btn">Watch</button></a><br><br>
	<a href="addBook.php"><button id="bookBtn" class="btn">Book</button></a><br><br>
 </div>

 </div>
  
 </body>
</html>
 