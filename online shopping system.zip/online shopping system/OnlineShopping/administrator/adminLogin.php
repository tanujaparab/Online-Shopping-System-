<!DOCTYPE html>
<html>
 <head>
  <title>
	Admin Login
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css"> 
  <link rel="stylesheet" type="text/css" href="../css/login.css">	 
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content------=--------------->
	  
 <div id="header">
  <div id="logo">
	 <a href="../index.php"><img src="../images/cartmagic_logo.png" width="275" height="70"/></a>
	  
  </div>
 </div>
	  
  <div id="loginBox">
   <h3 style="color: red">Login Into Your account</h3><br><hr><br>
   <form action="" method="post" id="loginForm">
	 <table>
	  <tr>
	   <td>Email ID:</td>   
	   <td><input type="email" name="email" class="inptField" required></td>
	  </tr> 
	  <tr>
       <td>Password:</td>   
       <td><input type="password" name="pass" class="inptField" required></td>
      </tr>
      <tr>
       <td></td>
       <td><input type="submit" name="submit" value="Sign In" id="submitButton"></td>
	   <?php include("adminsignin.php"); ?>
      </tr>
     </table>	
   </form>
  </div>

 </div>
  
 </body>
</html>
 