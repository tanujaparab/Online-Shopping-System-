<!DOCTYPE html>
<html>
 <head>
  <title>
	Add Mobile Product
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css"> 
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="../css/login.css">
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content---------------------->
	  
 <div id="header">
  <div id="logo">
	 <img src="../images/cartmagic_logo.png" width="275" height="70"/>
  </div>
	 
  <div id="adminHome">
	<a href="admin_index.php">Admin Home</a>
  </div>
 </div>
	  
 <div id="addProductBox">
   <h3 style="color: red">Add Mobile</h3><br><hr><br>
   <form action="" method="post" enctype="multipart/form-data">
	 <table class="addTableContent">
	  <tr>
	   <td>Mobile Name: </td>
	   <td><input type="text" name="mobileName" class="inptField" maxlength="50" required></td> 
	  </tr>
	  <tr>
		  <td>Prize: </td>
		  <td><input type="number" name="proPrize" class="inptField" max="1000000" required></td>
	  </tr> 
	  <tr>
		  <td>Choose Image: </td>  
		  <td><input type="file" name="image" required></td> 
	  </tr>
	  <tr>
		  <td>Brand Name: </td>
		  <td><input type="text" name="brandName" class="inptField" maxlength="50" required></td> 
	  </tr>
	  <tr>
		  <td>Color: </td>
		  <td><input type="text" name="proColor" class="inptField" maxlength="25" required></td>  
	  </tr>
	  <tr>
		  <td>RAM: </td>
		  <td><input type="text" name="ram" class="inptField" maxlength="10" required></td> 
	  </tr>
	  <tr>
	  <tr>
		  <td>ROM: </td>
		  <td><input type="text" name="rom" class="inptField" maxlength="10" required></td> 
	  </tr>
       <tr>   
		   <td>Display : </td>
		   <td><input type="text" name="display" class="inptField" maxlength="50" required></td>
	   </tr>
      <tr>
       <td></td>
       <td><input type="submit" name="submit" value="Add Product" id="submitButton"></td>
      </tr>
     </table>
	   
	 <table class="addTableContent">
	   <tr>
		   <td>Camera: </td>
		   <td><input type="text" name="camera" class="inptField" maxlength="50" required></td>
	   </tr>
	   <tr>
		   <td>Battery: </td>
		   <td><input type="text" name="battery" class="inptField" maxlength="20" required></td>
	   </tr>
	   <tr>
		   <td>Operating System: </td>
		   <td><input type="text" name="os" class="inptField" maxlength="50" required></td>
	   </tr>
	   <tr>
		   <td>Seller: </td>
		   <td><input type="text" name="seller" class="inptField" maxlength="40" required></td>
	   </tr>
	   <tr>
		   <td>Weight: </td>
		   <td><input type="text" name="weight" class="inptField" maxlength="10" required></td>
	   </tr>
	   <tr>
	    <td>Description: </td>
	    <td><textarea name="description" id="addr" rows="3" maxlength="200" required></textarea></td>
	   </tr>
	   <tr>
	    <td>Availability: </td>
	    <td><input type="text" name="availItems" class="inptField" max="999" required></td>
	   </tr>
	 </table>
   </form>
  </div>
	  
  <?php 
	if(isset($_POST['submit'])) {
		$con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
		
		//---------- Mobile Details----------------		
		$mobileName = $_POST['mobileName'];
		$proPrize = $_POST['proPrize'];
		$proColor = $_POST['proColor'];
		$brandName = $_POST['brandName'];
		$ram = $_POST['ram'];
		$rom = $_POST['rom'];
		$display = $_POST['display'];
		$camera = $_POST['camera'];
		$battery = $_POST['battery'];
		$os = $_POST['os'];
		$seller = $_POST['seller'];
		$weight = $_POST['weight'];
		$description = $_POST['description'];
		$availItems = $_POST['availItems'];
		
		//--------- upload image details-----------
		$imageName = $_FILES['image']['name'];
		$imageType = $_FILES['image']['type'];
		$tmpName = $_FILES['image']['tmp_name'];
		$location = "../images/Mobiles/";
		
		if($imageType == "image/jpeg" || $imageType == "image/jpg" || $imageType == "image/gif" || $imageType == "image/png" ) {
			if(move_uploaded_file($tmpName, $location.$imageName)) {
				if($sql = mysqli_query($con,"insert into mobiles (productName, productPrize, image, brandName, color, RAM, ROM, display, camera, battery, operatingSystem, seller, weight, productDescription, availableItems) values ('$mobileName','$proPrize','images/Mobiles/$imageName','$brandName',
                 '$proColor','$ram','$rom','$display','$camera','$battery','$os',
                 '$seller','$weight','$description','$availItems')")) {
	                  echo "Product Inserted SuccessFully";
                 } else {
	                 echo "Databse Error";
                 }
			} else {
				echo "Failed to upload..>";
			}
		} else {
			echo "Sorry, This file type is not allowed.";
		}

		
	}  
  ?>
 </div>
  
 </body>
</html>
 