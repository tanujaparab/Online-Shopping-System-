<!DOCTYPE html>
<html>
 <head>
  <title>
	Edit Product
  </title>
  <link rel="stylesheet" type="text/css" href="../css/index.css"> 
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="../css/login.css">
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content---------------------->
	  
 <div id="header">
  <div id="logo">
	 <img src="../images/cartmagic_logo.png" width="275" height="70"/>
  </div>
	 
  <div id="adminHome">
	<a href="admin_index.php">Admin Home</a>
  </div>
 </div>
	  
 <div id="editProductBox">
   <h3 style="color: red">Edit a Product</h3><br><hr><br>
   <span>Enter product ID to be Edited : </span>
   <form action="#" method="post" id="editForm">
	 <input type="number" name="productId" class="inptField" max="100000" required><br>
	 <input type="submit" value="Edit" name="editButton" id="submitButton">
   </form><br><br>
   <?php 
	if(isset($_POST['editButton'])) {
		
		function editProductForm($productId, $tableName) {
		 $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
		
		 if($qry = mysqli_query($con,"select * from $tableName where 
		                    productId='$productId'"));
		   $rowCount = mysqli_num_rows($qry);
		   if($rowCount > 0) {
		     $result = mysqli_fetch_row($qry);
			 
			 $getCols = mysqli_query($con,"SELECT * FROM 
			                  INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='mobiles'");
			// $colsRes = mysqli_fetch_row($getCols);
			// echo $colsRes[1];
			 while ($colsRes = mysqli_fetch_row($getCols)) {
				 echo $colsRes[3]."<br>";
			 }  
			
			   
			   
		/*	   echo "<form action='' method='post'>";
			    echo "<table>";
			     echo "<tr>";
			      echo "<td>Product Name:";
			   
			     echo "</tr>";
			    echo "</table>";
			   echo "</form>";
		   } else {
			   echo "No such Product Id available..";
		   }  */
		 }
		}
		
		$productId = $_POST['productId'];
		if($productId >= 10101 && $productId <= 20100) {
			editProductForm($productId,"mobiles");
		} else if($productId >= 20101 && $productId <= 25100) {
			editProductForm($productId,"menswear");
		} else if($productId >= 25101 && $productId <= 30100) {
			editProductForm($productId,"ladieswear");
		} else if($productId >= 30101 && $productId <= 35100) {
			editProductForm($productId,"childrenswear");
		} else if($productId >= 35101 && $productId <= 40100) {
			editProductForm($productId,"sportswear");
		} else if($productId >= 40101 && $productId <= 50100) {
			editProductForm($productId,"watches");
		} else if($productId >= 50101 && $productId <= 60100) {
			editProductForm($productId,"books");
		}else {
			 echo "No such Product Id available..";
		}
	} 
   ?>
 </div>
	  
 </div>
  
 </body>
</html>
 