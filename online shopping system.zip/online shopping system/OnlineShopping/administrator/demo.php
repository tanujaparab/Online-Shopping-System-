<?php
$userid = "125";
$name = "dddf";
$upload_time = 145236;

$mobileName = "sam";
$proPrize = 2563;
$imageName = "vsvsv";
$brandName = "bcd";
$proColor = "bad";
$ram = "rg";
$rom = "nd";
$display = "bdhd";
$camera = "vjvk";
$battery = "nml";
$os = "mjs";
$seller = "ndjaa";
$weight = "12k";
$description = "ndjdjsjsj";
$availItems = 2;

$con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());

if($sql = mysqli_query($con,"insert into mobiles (productName, productPrize, image, brandName, color, RAM, ROM, display, camera, battery, operatingSystem, seller, weight, productDescription, availableItems) values ('$mobileName','$proPrize','images/Mobiles/$imageName','$brandName','$proColor',
'$ram','$rom','$display','$camera','$battery','$os','$seller','$weight','$description',
'$availItems')")) {
	echo "Product Inserted SuccessFully";
} else {
	echo "Databse Error";
}

/*
INSERT INTO `mobiles` (`productId`, `productName`, `productPrize`, `image`, `brandName`, `color`, `RAM`, `ROM`, `display`, `camera`, `battery`, `operatingSystem`, `seller`, `weight`, `productDescription`, `availableItems`) VALUES
(10125, 'Apple iPhone 7 Plus', 60780, 'images/Mobiles/apple-iphone-7-plus.jpeg', 'Apple', 'Black', '2 GB', '128 GB', '13.97 cm (5.5 inch)', '12MP + 12MP | 7MP Front Camera', ' Li-Ion', ' iOS 10', ' PrimeTrading', '188 gm', 'The iPhone 7 Plus brings to you a heady combination of style and performance to enhance your smartphone experience. With its impressive internal storage, powerful camera system and long battery life.', 10) */

/*
if($sql = mysqli_query($con,"insert into demo
(field1,field2,field3) values 
('$mobileName','$proPrize','$imageName')")) {
	echo "Success";
} else {
	echo "Failed";
}

if($sql = mysqli_query($con,"insert into demo 
(field1,field2,field3) values 
('$mobileName','$proPrize','$imageName')")) {
	echo "Success";
} else {
	echo "Failed";
}  */

?>