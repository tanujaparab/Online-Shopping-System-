<!DOCTYPE html>
<html>
 <head>
  <title>
	 Shop Online - Home
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" type="text/css" href="css/login.css"> 
 </head>
	
  <body>
   <div id="wrapper">
	 <div id="header">
        <div id="logo">
	     <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/></a> 
        </div>
     </div>
		
  <?php
      if(isset($_POST['signupSubmit'])) {
	  $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
	
	$fname = mysqli_real_escape_string($con, $_POST['fname']);
	$lname = mysqli_real_escape_string($con, $_POST['lname']);
	$mobileNo = mysqli_real_escape_string($con, $_POST['mobileNo']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$pass = mysqli_real_escape_string($con, $_POST['pass']);
	$retPass = mysqli_real_escape_string($con, $_POST['retPass']);
	$gender = mysqli_real_escape_string($con, $_POST['gender']);
	$addr = mysqli_real_escape_string($con, $_POST['addr']);
	$city = mysqli_real_escape_string($con, $_POST['city']);
	$pinCode = mysqli_real_escape_string($con, $_POST['pinCode']);
	
	$sql = mysqli_query($con,"select * from customers where email='$email'");
	$rowsCount = mysqli_num_rows($sql);
	  if($rowsCount > 0) {
		 echo "<div id='msgBox'>";
		 echo "This Email is already registered..<br><br>";
		 echo "<a href='signup.php'>Signup Again</a>";
		 echo "</div>";
		 mysqli_close($con);
	  } else {
		 if($pass != $retPass) {
			echo "<div id='msgBox'>";
			echo "Passwords does not match..<br><br>"; 
			echo "<a href='signup.php'>Signup Again</a>";
			echo "</div>"; 
			mysqli_close($con);
		 } else {
			$pass = md5($pass);   //-----Password Encryption--------
			
			//----------Inserting data into databse--------------
			$sql = mysqli_query($con,"insert into customers (firstName, lastName, mobileNo, email, password, gender, address, pinCode, city, orderId, cartProducts, cartQtys) values ('$fname','$lname','$mobileNo','$email','$pass','$gender','$addr',
			'$pinCode','$city','0','0','0')");
			 
			echo "<div id='msgBox'>";
			echo "Welcome, You are Signed up successfully..<br><br>"; 
			echo "<a href='login.php'>Login Page</a>";
			echo "</div>";
			
			mysqli_close($con);
		 }
	  }
    } else {
	      header("location:signup.php");
    }
		
?> 
	  
   </div>
	  
  </body>
</html>














