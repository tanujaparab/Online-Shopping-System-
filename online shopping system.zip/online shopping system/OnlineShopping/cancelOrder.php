<?php
 if(isset($_REQUEST['orderId'])) {
	 $orderId = $_REQUEST['orderId'];
	 $orderAmnt = $_REQUEST['orderAmnt'];
	 
     $con = mysqli_connect("localhost","root","","onlineshopping") or        
        die(mysqli_connect_error());
     $qry = mysqli_query($con,"delete from orders where  
		orderId='$orderId'"); 
	 
	 session_start();
	 $custId = $_SESSION["userId"];
	 $balQry = mysqli_query($con,"select * from bankaccount where  
		custId='$custId'");
	 $balRes = mysqli_fetch_row($balQry);
	 $balance = $balRes[7];
	 
	 $newBalance = $balance + $orderAmnt;
	 $balQry2 = mysqli_query($con,"update bankaccount set balance=$newBalance where  
		custId='$custId'");
	 
     mysqli_close($con);
	 header("location:myOrders.php");
	 
 } else {
	 header("location:index.php");
 }
?>