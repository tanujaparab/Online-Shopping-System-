<?php
  session_start();
  if(!isset($_SESSION["userId"])) {
	session_destroy();
	header("location:index.php");   
  } else {
	
?>

<!DOCTYPE html>
<html>
 <head>
  <title>
	 Place Order
  </title> 
  <link rel="stylesheet" type="text/css" href="css/placeOrder.css">
	 
 <script src="jquery-3.3.1.min.js"></script>
  <script>
   $(document).ready(function(){
       $('input[type="radio"]').click(function(){
           var inputValue = $(this).attr("value");
           if(inputValue == "debit") {
	   	      $("#payMethodCod").css("display", "none");
		      $("#payMethodDebit").css("display", "block");
		   } else {
		      $("#payMethodDebit").css("display", "none");
		      $("#payMethodCod").css("display", "block");
		   }
       });
    });
  </script>
 </head>
	
  <body>
    <div id="wrapper">
     <div id="header">
       <div id="logo">
	     <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/>
         </a>
       </div>
	 </div>
		
	 <?php
		function getCartProduct($qry2,$i,$accCartQty) {
			$quantities = $accCartQty;
			$qtyArray = explode("_",$quantities);
            $qty = $qtyArray[$i];
			
			$res2 = mysqli_fetch_row($qry2);
				
	    	echo "<tr>";
			  echo "<td class='proFeature'><img src='$res2[3]' width='40' height='70'></td>";
			  echo "<td class='proFeature'>".$res2[1]."</td>";
			  echo "<td class='proFeature'>".$qty."</td>";
			  $prize = $qty * $res2[2];
			   echo "<td class='proFeature'>&#8377; $prize/-</td>";
			echo "</tr>";
			
			global $totalAmount;
			//----------calculating total amount according to qtys----------
			$totalAmount = $totalAmount + ($qty * $res2[2]); 
		}
	 ?>
	
	 <div id="placeOrderBox">
	   <div class="loginEmail">
	    <span class="elementHeader">1. Login</span><br><br>
	    <?php
		   if(isset($_SESSION["userId"])) {
			 $custId = $_SESSION["userId"];
			  
			 $con = mysqli_connect("localhost","root","","onlineshopping") or         die(mysqli_connect_error());
			 $sql = mysqli_query($con,"select * from customers where    
			         custId='$custId'");
			 $res = mysqli_fetch_array($sql);
			 $fname = $res["firstName"];
			 $lname = $res["lastName"];
			 $emailId = $res["email"];
			 echo $fname." ".$lname." - <b>".$emailId."</b>"; 
		   }
		?>
	   </div>
		 
	   <div class="deliveryAddress">
		 <span class="elementHeader">2. Delivery Address</span><br><br>
		 <?php
		   $dlvrAddress = $res["address"];
		   $city = $res["city"];
		   echo $dlvrAddress.".  City-".$city;
		 ?>
	   </div>
		 
	   <div class="orderSummary">
		<span class="elementHeader">3. Order Summary</span><br><br>	
		<?php
         $accCartItems = $res["cartProducts"];
		 $accCartQty = $res["cartQtys"];
		   
          $productArray = explode("_",$accCartItems);
		  $productCount = count($productArray);
		  $noOfProducts = --$productCount; //Neglecting first 0 by decreament
		  
		  echo "<table id='cartItemsTable'>";
		  $i = 1;  
		  while($i <= $noOfProducts) {
		   if($productArray[$i] >= 10101 && $productArray[$i] <= 20100){
			  $qry2 = mysqli_query($con,"select productId, productName, productPrize, image from mobiles where productId='$productArray[$i]'"); 
			  getCartProduct($qry2,$i,$accCartQty);
		   }  else if($productArray[$i] >= 20101 && $productArray[$i] <= 25100) {
			  $qry2 = mysqli_query($con,"select productId, productName, productPrize, image from menswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry2,$i,$accCartQty); 
		   } else if($productArray[$i] >= 25101 && $productArray[$i] <= 30100) {
			  $qry2 = mysqli_query($con,"select productId, productName, productPrize, image from ladieswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry2,$i,$accCartQty); 
		   } else if($productArray[$i] >= 30101 && $productArray[$i] <= 35100) {
			  $qry2 = mysqli_query($con,"select productId, productName, productPrize, image from childrenswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry2,$i,$accCartQty); 
		   } else if($productArray[$i] >= 25101 && $productArray[$i] <= 40100) {
			  $qry2 = mysqli_query($con,"select productId, productName, productPrize, image from sportswear where productId='$productArray[$i]'"); 
			  getCartProduct($qry2,$i,$accCartQty); 
		   } else if($productArray[$i] >= 40101 && $productArray[$i] <= 50100) {
			  $qry2 = mysqli_query($con,"select productId, productName, productPrize, image from watches where productId='$productArray[$i]'"); 
			  getCartProduct($qry2,$i,$accCartQty); 
		   } else if($productArray[$i] >= 50101 && $productArray[$i] <= 60100) {
			  $qry2 = mysqli_query($con,"select productId, productName, productPrize, image from books where productId='$productArray[$i]'"); 
			  getCartProduct($qry2,$i,$accCartQty); 
		   }  
			
		   $i++;  
		  }
		 echo "</table><br>"; 
		   
		  echo "<div id='totalAmount'>Total Amount : &#8377; <span   
		          id='tAmount'>".$totalAmount."</span>/-</div>";
		  $_SESSION["ttlAmount"] = $totalAmount;
	       mysqli_close($con);
		?>
	   </div>

	   <div class="paymentDetails">
		 <span class="elementHeader">4. Payment Details</span><br><br>
		  <input type="radio" name="payOpt" id="debit" value="debit" checked required>Debit/ATM 
		             card &nbsp;
          <input type="radio" name="payOpt" id="cod" value="cod">Cash On Delivery<br><br>
		   
		   <div id="payMethodDebit">
		    <form method="post" action="payValidation.php">
			 <input type="number" name="cardNumber" class="payInput" placeholder="Enter Card Number" required><br><br>
             <input type="password" name="cvv" class="payInput" placeholder="CVV" maxlength="3" required><br><br>
			 <input type="submit" name="paySubmitDebit" value="Continue" id="paySubmitBtn">
		    </form><br>
		   </div>
		   
		 <div id="payMethodCod">
		    Your cash on Delivery Order Amount is Rs.<?php echo $totalAmount; ?><br><br>
			<a href="codVarify.php"><button id="codPlaced">Place Order</button></a>
		 </div>
		   
	 </div>
	 	
	</div>	
  </div>
</body>
</html>

<?php
  }
?>