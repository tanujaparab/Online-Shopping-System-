<?php
  $proId = $_REQUEST['proId'];

  session_start();
  if(isset($_SESSION["userId"])) {
	  $custId = $_SESSION["userId"];
	  
	  include("include-files/dbConnection.php");
	  
	  $qry = mysqli_query($con,"select * from customers where custId='$custId'");
	  $res = mysqli_fetch_array($qry);
	  $accCartItems = $res["cartProducts"];
	  $accCartQty = $res["cartQtys"];
	  
	  $accCartItems = $accCartItems.'_'.$proId;
	  $accCartQty = $accCartQty.'_1';
	  
      $updateQry = mysqli_query($con,"update customers set cartProducts='$accCartItems', cartQtys='$accCartQty' where custId='$custId'");
	  
	  mysqli_close($con);
	  header("location:myCart.php");
	  
  } else if(isset($_COOKIE['cartItems']) && isset($_COOKIE['quantities'])) { 
	  
	$cartItems = $_COOKIE['cartItems'];
	$quantities = $_COOKIE['quantities'];
	  
	$cartItems = $cartItems.'_'.$proId;
    setcookie("cartItems",$cartItems,time()+(86400*60));
	  
	$quantities = $quantities."_1";
    setcookie("quantities",$quantities,time()+(86400*60));
	  
    header("location:myCart.php");
	  
  } else {
	  setcookie("cartItems","0",time()+(86400*60));
	  setcookie("quantities","0",time()+(86400*60));
      header("location:addToCart.php?proId=$proId");
  }
?>