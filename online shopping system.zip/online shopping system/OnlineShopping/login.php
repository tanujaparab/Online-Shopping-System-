<?php
  session_start();
  if(isset($_SESSION['userId'])) {
	  header("location:index.php");
  } else {
	 session_destroy();
	  
?> 

<!DOCTYPE html>
<html>
 <head>
  <title>
	 Login
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css"> 
  <link rel="stylesheet" type="text/css" href="css/login.css"> 
 </head>
	
 <body>
  <div id="wrapper">
	<!---------------Header Content------=--------------->
	  
	  <div id="header">
  <div id="logo">
	 <a href="index.php"><img src="images/cartmagic_logo.png" width="275" height="70"/>
     </a>
  </div>
	
  <div id="rightHeaderBox">
	<a href="myCart.php">
     <div id="cartBox"><img src="images/emptyCartLight.png" width="36" height="36" 
                        align="middle"/>
	   <span id="cartText">
		 Cart 
		 <span id="cartCount">
         <?php
		   if(isset($_COOKIE['cartItems'])) {
			 $cartItems = $_COOKIE['cartItems'];
			 $productArray = explode("_",$cartItems);
             $noOfProducts = count($productArray);
             $noOfProducts = --$noOfProducts;
			 echo $noOfProducts;
           } else {
              echo "0";
           }
         ?>
          </span>
	   </span>
      </div>
	 </a>

	 <a href="signup.php">
       <div id="signUpButton">
          Sign Up 
       </div>
	 </a>
  </div>
	
  <div id="searchBar">
    <input type="text" id="searchBox" placeholder="Search products..."                        name="searchProduct">
	<button id="searchButton"><img src="images/searchIcon.png" width="19" height="19">
	</button>
  </div>
  </div>
 
  <div id="loginBox">
   <h3 style="color: red">Login Into Your account</h3><br><hr><br>
   <form action="loginValidation.php?loginStatus=<?php 
	   if(isset($_REQUEST['loginStatus'])) {
		$status = $_REQUEST['loginStatus'];
		echo $status;
	   } else {
		  echo "notForCheckout"; 
	   }
		?>" method="post" id="loginForm">
	 <table>
	  <tr>
	   <td>Email ID:</td>   
	   <td><input type="email" name="email" class="inptField" max="50" required></td>
	  </tr> 
	  <tr>
       <td>Password:</td>   
       <td><input type="password" name="pass" class="inptField" max="25" required></td>
      </tr>
      <tr>
       <td></td>
       <td><input type="submit" name="loginSubmit" value="Sign In" id="submitButton"></td>
      </tr>
     </table>	
   </form>
  </div>

 </div>
  
 </body>
</html>

<?php
  }
?> 
 