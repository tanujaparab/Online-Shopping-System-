-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2020 at 04:33 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineshopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `adminId` int(11) NOT NULL,
  `userId` varchar(60) NOT NULL,
  `password` varchar(150) NOT NULL,
  `orderIds` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`adminId`, `userId`, `password`, `orderIds`) VALUES
(1, 'tanu01@gmail.com', 'tanu123', '1');

-- --------------------------------------------------------

--
-- Table structure for table `bankaccount`
--

CREATE TABLE `bankaccount` (
  `accountId` int(11) NOT NULL,
  `custId` int(6) NOT NULL,
  `custAddress` varchar(200) NOT NULL,
  `custMobile` int(10) NOT NULL,
  `debitCardNumber` varchar(20) NOT NULL,
  `cvvNo` int(5) NOT NULL,
  `password` varchar(150) NOT NULL,
  `balance` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bankaccount`
--

INSERT INTO `bankaccount` (`accountId`, `custId`, `custAddress`, `custMobile`, `debitCardNumber`, `cvvNo`, `password`, `balance`) VALUES
(1, 1, 'Shahapur', 800764231, '12348765', 101, '1234', 53610),
(2, 2, 'Ambernath', 2147483647, '12345678', 150, '12345', 99123),
(3, 3, 'Delhi', 451236875, '1234567887654321', 200, '8888', 87507),
(5, 8, 'vikhroli', 975727666, '321654987', 0, '12345', 262960);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `productId` int(11) NOT NULL,
  `productName` varchar(100) DEFAULT NULL,
  `productPrize` int(6) DEFAULT NULL,
  `image` varchar(60) DEFAULT NULL,
  `bookCategory` varchar(15) DEFAULT NULL,
  `ISBN` varchar(25) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `publication` varchar(40) DEFAULT NULL,
  `language` varchar(25) DEFAULT NULL,
  `binding` varchar(20) DEFAULT NULL,
  `seller` varchar(40) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `availableItems` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`productId`, `productName`, `productPrize`, `image`, `bookCategory`, `ISBN`, `author`, `publication`, `language`, `binding`, `seller`, `description`, `availableItems`) VALUES
(50101, 'The Perfect Us - (Book)', 98, 'images/Books/the-perfect-us-book.jpeg', 'Bestsellers', '9780143426592', ' Datta Durjoy', 'Penguin', 'English', 'Paperback', ' TrueComRetail', NULL, 5),
(50102, 'Train to Pakistan - (Book)', 120, 'images/Books/train-to-pakistan-book.jpeg', 'Indian', '9780143065883', 'Khushwant Singh', 'Penguin', ' English', 'Paperback', ' TrueComRetail', 'Train To Pakistan shows what it must have been for the people caught in the middle of the Partition, when a country is divided along communal lines.', 4),
(50103, 'My Experiments with Truth - Gandhi - (Book)', 125, 'images/Books/my-experiments-with-truth-book.jpeg', 'Autobiography', '9788190888790', ' Mahadev Desai', 'Lexicon Books', 'English', 'Paperback', ' DHANPATRAI', 'The Father of the Indian Nation tells the story of his life in My Experiments With Truth, the autobiography of Mahatma Gandhi.', 5),
(50104, 'Head First Java 2 Edition - (Book)', 839, 'images/Books/head-first-java-book.jpeg', 'Academic', '9788173666025', ' Kathy Sierra', 'O\' Reilly', 'English', 'Paperback', ' TMB123', 'This is a book that is tailored for Java novices. Ideal for those who are interested in learning Java but have been put off by the complexities of learning the language.', 10),
(50105, 'The Palace of Illusions - (Book)', 248, 'images/Books/the-palace-of-illusions.jpeg', 'Indian', '9780330458535', ' Divakaruni Chitra', 'Pan Macmillan', 'English', 'Paperback', ' TrueComRetail', 'A marriage of history and myth, The Palace of Illusions reimagines the world-famous Indian Epic, the Mahabharata.', 10),
(50106, 'The Girl in Room 105 -(Book)', 125, 'images/Books/the-girl-in-room-105-book.jpeg', 'Bestsellers', '9781542040464', 'Chetan Bhagat', 'Amazon Publishing', 'English', 'Paperback', ' TrueComRetail', 'Keshav finds himself in a mess when his girlfriend breaks up with him. Although Zara moves on with her life, Keshav is unable to do so and resorts to drinking. but on Zaraâ€™s birthday, Keshav gets a message from Zara asking him to visit her in her old hostel room 105. Will Keshav go?', 5),
(50107, 'Rich Dad Poor Dad - (Book)', 142, 'images/Books/rich-dad-poor-dad-book.jpeg', 'Bestsellers', '9788186775219', 'Robert T. Kiyosaki', 'Manjul Publishing House', 'Hindi', 'Paperback', 'TrueComRetail', 'Rich Dad Poor Dad speaks about the lifelong monetary problems experienced by his poor dad and the life experiences of the rich dad.', 3),
(50108, 'Steve Jobs by Walter Isaacson - (Book)', 321, 'images/Books/steve-jobs-by-walter-isaacson-book.jpeg', 'Autobiography', '9780349140438', 'Walter Isaacson', 'Hachette', 'English', 'Paperback', ' TrueComRetail', 'This book is the acclaimed, internationally best-selling biography of a business magnate, investor and co-founder of Apple Inc.', 10),
(50109, 'Photoshop Elements 9 Digital Classroom - (Book)', 4100, 'images/Books/photoshop-elements-9-classroom-book.jpeg', 'Academic', '9780470932308', 'John Wiley', 'John Wiley & Sons Inc', 'English', 'Paperback', ' PrimeCentralSales', 'Learn Photoshop Elements at your own pace with this unique book-and-DVD training package Photoshop Elements is the leading image-editing software.', 8),
(50110, 'Wings of Fire - (Book)', 223, 'images/Books/wings-of-fire-book.jpeg', 'Autobiography', '9788173711466', 'APJ Abdul Kalam', 'Orient Black Swan', 'English', 'Paperback', ' TrueComRetail', 'One of the most inspiring and popular autobiographies to read is Late Abdul Kalamâ€™s Wings of Fire. In this book, the former president shares his personal experiences and minutest details of his life.', 10),
(50111, 'Playing It My Way - (Book)', 350, 'images/Books/playing-it-my-way-book.jpeg', 'Autobiography', '9781473605176', 'Sachin Tendulkar', 'Hodder & Stoughton General Publication', 'English', 'Paperback', ' FutureCom', 'Through this book, Sachin talks about his journey through the world of Cricket that lasted for over two decades. He also speaks of the relationship he had with the people around him.', 12),
(50112, 'A Brief History Of Time - (Book)', 224, 'images/Books/a-brief-history-of-time-book.jpeg', 'Bestsellers', '9780553175219', 'Stephen Hawking', 'Transworld Publishers Ltd', 'English', 'Paperback', 'FutureCom', 'A Brief History of Time, authored by the legendary theoretical physicist Stephen Hawking, is considered to be the holy grail of populalizing scientific writing and ever since it was published for the first time in 1988.', 7),
(50113, 'Bhagavad-gita as it Is 1st Edition - book', 150, 'images/Books/bhagavad-gita-as-it-is-book.jpeg', 'Indian', '9789382176398', 'Bhaktivedanta Swami', 'Bhaktivedanta Book Trust', 'Marathi', 'Hardcover', 'SansrutiBooks', '\r\nThe Bhagavad - Gita is the main source-book on yoga and a concise summary of India\'s Vedic wisdom. Yet remarkably, the setting for this best-known classic of spiritual literature is an ancient Indian battlefield.', 10),
(50114, 'Java 8 Programming Black Book', 635, 'images/Books/java-programming-black-book.jpeg', 'Academic', '9789351197584', 'James Soir', 'Wiley', 'English', 'Paperback', ' RetailNet', 'Java 8 Programming Black Book covers the details of java programing language', 5),
(50115, 'Principles and Practice of Accounting - book', 760, 'images/Books/principles-and-practice-of-accounting-book.jpeg', 'Academic', '9789353162467', 'P C Tulsian', 'Mcgraw Hill', 'English', 'Paperback', ' TrueComRetail', 'This book is helpful for student who pursue career in commerce', 2),
(50116, 'The Secret of the Nagas - Book', 238, 'images/Books/the-secret-of-the-nagas.jpeg', 'Indian', '9789381626344', 'Amish Tripathi', 'Westland Publications Limited', 'English', 'Paperback', ' TrueComRetail', 'The Secret of The Nagas is the second book in the Shiva trilogy and is a sequel to The Immortals of Meluha.', 3),
(50117, 'Think and Grow Rich - (Book)', 200, 'images/Books/think-and-grow-rich-book.jpeg', 'Bestsellers', '9788192910918', 'Napoleon Hill', 'Amazing Reads', 'English', 'Paperback', ' TrueComRetail', 'This book describes actionable techniques that can be used by anyone to grow rich. In many places, the author has used short stories and examples that help explain the concept at hand in an interesting manner.', 2),
(50118, 'Sherlock Holmes: The Secret Journals', 325, 'images/Books/sherlock-holmes-the-secret-journals.jpeg', 'Bestsellers', '9788184955798', 'June Thomson', 'Jaico Publishing House', 'English', 'Paperback', 'RetailNet', 'Book Type: \r\nFiction Book', 10),
(50119, 'Mein Kampf - (Book)', 236, 'images/Books/mein-kampf-book.jpeg', 'Autobiography', '9789381688212', ' Adolf Hitler', 'Future', 'English', 'Paperback', ' FutureCom', '\r\nHitler is one such name which sends shivers down peopleâ€™s spine even today. The man has penned down Mein Kampf which is an autobiography that gives the readers an insight to his life.', 5),
(50120, 'Three Thousand Stitches - Book', 150, 'images/Books/three-thousand-stitches-book.jpeg', 'Autobiography', '9780143440055', 'Sudha Murty ', 'Penguin', 'English', 'Paperback', 'RetailNet', 'Three Thousand Stitches -: Ordinary People, Extraordinary Lives is a book containing eleven different extraordinary tales that are inspired by Sudha Murthyâ€™s life.', 3),
(50121, 'Life is What You Make it - Book', 100, 'images/Books/life-is-what-you-make-it-book.jpeg', 'Indian', '9789380349305', 'Preeti Shenoy', 'Srishti Publishers', 'English', 'Paperback', 'SuperCom', ' book of love, hope, and how determination can overcome even your destiny - Life is What You Make of It by Preeti Shenoy was in the â€œTop books of 2011â€ as per the Nielsen list which is published in Hindustan Times.', 5),
(50122, 'The Forgotten Daughter - Book', 288, 'images/Books/the-forgotten-daughter-book.jpeg', 'Indian', '9781542040464', ' Renita Dâ€™Silva', 'Fingerprint! Publishing', 'English', 'Paperback', ' TrueComRetail', 'None', 0),
(50123, 'Object-Oriented Programming with C++', 344, 'images/Books/object-oriented-programming-with-c++.jpeg', 'Academic', '9780330458535', 'Balagurusamy', 'Mcgraw Hill', 'English', 'Paperback', ' TrueComRetail', 'The book aims at providing an all-round enrichment of knowledge in the area of object-oriented programming with C++ as the implementation of language.', 5),
(50124, 'Computer System Architecture - Book', 400, 'images/Books/computer-system-architecture-book.jpeg', 'Academic', '9780470932308', 'Morris Mano', 'Pearson', 'English', 'Paperback', ' TrueComRetail', 'None', 6),
(50125, 'ram', 250, 'images/Books/ram.jpg', 'Indian', '9788173666027', 'amish', 'Penguin', 'english', 'paperback', 'TrueComRetail', 'This book is the acclaimed, internationally best-s...', 10);

-- --------------------------------------------------------

--
-- Table structure for table `childrenswear`
--

CREATE TABLE `childrenswear` (
  `productId` int(11) NOT NULL,
  `productName` varchar(50) DEFAULT NULL,
  `productPrize` varchar(7) DEFAULT NULL,
  `image` varchar(60) DEFAULT NULL,
  `brandName` varchar(50) DEFAULT NULL,
  `clothingCategory` varchar(15) DEFAULT NULL,
  `seller` varchar(40) DEFAULT NULL,
  `primaryColor` varchar(25) DEFAULT NULL,
  `secondaryColor` varchar(25) DEFAULT NULL,
  `size` varchar(25) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `sleeve` varchar(25) DEFAULT NULL,
  `pattern` varchar(25) DEFAULT NULL,
  `fabric` varchar(25) DEFAULT NULL,
  `ocassion` varchar(25) DEFAULT NULL,
  `availableItems` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `childrenswear`
--

INSERT INTO `childrenswear` (`productId`, `productName`, `productPrize`, `image`, `brandName`, `clothingCategory`, `seller`, `primaryColor`, `secondaryColor`, `size`, `type`, `sleeve`, `pattern`, `fabric`, `ocassion`, `availableItems`) VALUES
(30101, 'Boys Festive & Party Kurta', '400', 'images/Clothing/boys-festive&party-kurta.jpeg', 'Digimart', 'Kurta', ' SBNFASHION', 'Black', 'Gray', NULL, ' Kurta, Waistcoat and Pyjama', NULL, ' Embellish', ' Art Silk', 'Festive & Party', 6),
(30102, 'Girls Midi/Knee Length Casual Dress', '274', 'images/Clothing/girls-midi-knee-length-casual-dress.jpeg', 'FTC Fashions', 'Dress', ' NIKUNJFASHION', ' Red', 'White', ' 7 - 8 Years', ' Layered', '', '', ' Cotton Lycra Blend', ' Casual', 3),
(30103, 'Boys Solid Cotton Blend T Shirt', '419', 'images/Clothing/boys-solid-cotton-blend-tshirt.jpeg', 'Provogue', 'T-shirt', ' RetailNet', 'Maroon', 'Sky Blue', ' 7 - 8 Years', '', ' Half Sleeve', 'Solid', ' Cotton Blend', ' Casual', 6),
(30104, 'Boys Festive & Party Kurta, Dhoti Pant', '442', 'images/Clothing/boys-festive-and-party-kurta-dhoti-pant.jpeg', 'FTC Fashions ', 'Kurta', ' NIKUNJFASHION', ' Gold', '', ' 3 - 4 Years', ' Kurta, Dhoti Pant & Dupatta ', ' Full Sleeve', ' Self Design', ' Art Silk', '', 8),
(30105, 'Boys Printed Polycotton T Shirt ', '223', 'images/Clothing/boys-printed-polycotton-tshirt .jpeg', 'Grand Stitch', 'T-shirt', ' GRANDSTITCH', ' Blue', '', ' 5 - 6 Years', ' Round Neck', ' Full Sleeve', ' Printed', ' Polycotton', 'Casual', 15),
(30106, 'Girls Maxi/Full Length Party Dress', '314', 'images/Clothing/girls-maxi-full-length-party-dress.jpeg', 'FTC Fashions ', 'Dress', ' NIKUNJFASHION', ' White', '', ' 5 - 6 Years', ' Gathered', ' Sleeveless', ' Self Design', ' Cotton Blend', ' Party', 6);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `custId` int(11) NOT NULL,
  `firstName` varchar(40) DEFAULT NULL,
  `lastName` varchar(40) DEFAULT NULL,
  `mobileNo` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `gender` char(10) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `pinCode` int(6) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `orderId` varchar(50) DEFAULT NULL,
  `cartProducts` varchar(100) DEFAULT NULL,
  `cartQtys` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`custId`, `firstName`, `lastName`, `mobileNo`, `email`, `password`, `gender`, `address`, `pinCode`, `city`, `orderId`, `cartProducts`, `cartQtys`) VALUES
(1, 'Bhavesh', 'Sande', '8007967449', 'bhaveshat11@gmail.com', '62e34971b79a8fa930b473b315cc681f', 'Male', '103, Onkar Apt, Kamalnagar, Shahapur, Thane', 421601, 'Shahapur', '0', '0_10102', '0_1_3'),
(2, 'Ankita', 'Rane', '1234567890', 'anki98@gmail.com', '752d2c9ecfe079e5e5f3539f4d750e5c', 'Female', 'Gayatri Apt., Ambernath', 412365, 'Ambernath', '0', '0_40101_40102', '0_1_1'),
(3, 'Suresh', 'Rane', '1234567812', 'su@gmail.com', '733d7be2196ff70efaf6913fc8bdcabf', 'Male', 'Thane', 421053, 'Thane', '0', '0', '0'),
(4, 'Tanuja', 'Parab', '2959484', 'tanuja@gmail.com', '202cb962ac59075b964b07152d234b70', 'Female', 'Vikhroli', 64744, 'Mumbai', '0', '0', '0'),
(5, 'vishal', 're', '1234567898', 'vishalr1@gmail.com', '202cb962ac59075b964b07152d234b70', 'Male', 'dombivali', 400089, 'thane', '0', '0_10101', '0_1'),
(6, 'tanuja', 'p', '1234567890', 'parabt@gmail.com', '202cb962ac59075b964b07152d234b70', 'Female', 'mumbai', 400083, 'thane', '0', '0_10101', '0_1'),
(7, 'tanuja', 'parab', '1234567890', 'tanuja4@gmail.com', '202cb962ac59075b964b07152d234b70', 'Female', 'vikhroli e', 400083, 'mumbai ', '0', '0', '0'),
(8, 'tanuja', 'parab', '9757276669', 'tanuja2@gmail.com', '621bf66ddb7c962aa0d22ac97d69b793', 'Female', 'vikhroli', 400083, 'mumbai', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `deliveryboy`
--

CREATE TABLE `deliveryboy` (
  `dbId` int(11) NOT NULL,
  `dbName` varchar(40) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `orderIds` varchar(100) NOT NULL,
  `orderRecieptIds` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deliveryboy`
--

INSERT INTO `deliveryboy` (`dbId`, `dbName`, `Mobile`, `orderIds`, `orderRecieptIds`) VALUES
(1, 'Suresh Shinde', '8223336665', '0', '0'),
(2, 'Madhav Roy', '7125635246', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ladieswear`
--

CREATE TABLE `ladieswear` (
  `productId` int(11) NOT NULL,
  `productName` varchar(50) DEFAULT NULL,
  `productPrize` varchar(7) DEFAULT NULL,
  `image` varchar(60) DEFAULT NULL,
  `brandName` varchar(50) DEFAULT NULL,
  `clothingCategory` varchar(15) DEFAULT NULL,
  `seller` varchar(40) DEFAULT NULL,
  `color` varchar(25) DEFAULT NULL,
  `size` varchar(15) DEFAULT NULL,
  `blousePiece` varchar(25) DEFAULT NULL,
  `sareeLength` varchar(10) DEFAULT NULL,
  `pattern` varchar(25) DEFAULT NULL,
  `fabric` varchar(25) DEFAULT NULL,
  `neckType` varchar(25) DEFAULT NULL,
  `length` varchar(15) DEFAULT NULL,
  `sleeve` varchar(20) DEFAULT NULL,
  `availableItems` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ladieswear`
--

INSERT INTO `ladieswear` (`productId`, `productName`, `productPrize`, `image`, `brandName`, `clothingCategory`, `seller`, `color`, `size`, `blousePiece`, `sareeLength`, `pattern`, `fabric`, `neckType`, `length`, `sleeve`, `availableItems`) VALUES
(25101, 'Embroidered Blue Georgette Saree', '629', 'images/Clothing/embroidered-blue-georgette-saree.jpeg', 'Kuki Fashion', 'Saree', ' Kuki', 'Blue and Pink', NULL, ' Unstitched', ' 5.5 m', 'Embroidered', ' Georgett', NULL, NULL, NULL, 10),
(25102, 'Women Printed Gown Kurta', '749', 'images/Clothing/women-printed-gown-kurta.jpeg', 'Gulmohar Jaipur', 'kurta', ' GulmoharCrafts', ' Blue', 'Large', '', '', ' Printed', ' Cotton Blend', 'Chinese Neck', '', ' 3/4 Sleeve', 5),
(25103, 'Casual Floral Print Women Kurti ', '426', 'images/Clothing/casual-floral-print-women-kurti.jpeg', 'Krapal ', 'kurta', ' krapal', 'Pink-Orange', 'Large', '', '', ' Floral Print', ' Cotton Blend', ' Round Neck', '', '', 3),
(25104, 'Women Fit and Flare Multicolor Dress', '509', 'images/Clothing/women-fit-and-flare-multicolor-dress.jpeg', 'U&F', 'Western', 'MarketWap', 'White-Blue', 'Medium', '', '', ' Self Design', ' Polycotton', '', ' Mini/Short', ' 3/4 Sleeve', 5),
(25105, 'Women Fit and Flare Yellow Dress', '502', 'images/Clothing/women-fit-and-flare-yellow-dress.jpeg', 'U&F ', 'Western', 'SuperCom', 'Yellow', 'Small', '', '', ' Solid', 'Polycotton', ' Round Neck', 'Knee Length', ' 3/4 Sleeve', 4),
(25106, 'Self Design Kanjivaram Art Silk Saree', '1350', 'images/Clothing/self-design-kanjivaram-art-silk-saree.jpeg', 'C J 129 ', 'Saree', ' Cjenterprise', 'Blue-Gold', '', 'Unstitched', '', 'Self Design', 'Art Silk', '', ' 5.5 m', '', 8);

-- --------------------------------------------------------

--
-- Table structure for table `menswear`
--

CREATE TABLE `menswear` (
  `productId` int(11) NOT NULL,
  `productName` varchar(50) DEFAULT NULL,
  `productPrize` varchar(6) DEFAULT NULL,
  `image` varchar(60) DEFAULT NULL,
  `brandName` varchar(50) DEFAULT NULL,
  `clothingCategory` varchar(10) DEFAULT NULL,
  `seller` varchar(40) DEFAULT NULL,
  `color` varchar(25) DEFAULT NULL,
  `size` varchar(15) DEFAULT NULL,
  `fit` varchar(20) DEFAULT NULL,
  `sleeve` varchar(20) DEFAULT NULL,
  `pattern` varchar(25) DEFAULT NULL,
  `fabric` varchar(25) DEFAULT NULL,
  `neckType` varchar(25) DEFAULT NULL,
  `stretchable` varchar(5) DEFAULT NULL,
  `closure` varchar(20) DEFAULT NULL,
  `rise` varchar(20) DEFAULT NULL,
  `availableItems` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menswear`
--

INSERT INTO `menswear` (`productId`, `productName`, `productPrize`, `image`, `brandName`, `clothingCategory`, `seller`, `color`, `size`, `fit`, `sleeve`, `pattern`, `fabric`, `neckType`, `stretchable`, `closure`, `rise`, `availableItems`) VALUES
(20101, 'Highlander Men\'s Solid Casual Shirt', '581', 'images/Clothing/highlander-mens-solid-casual-shirt.jpeg', 'Highlander', 'Shirt', ' RetailNet', ' Light Blue', 'L', 'Slim', ' Full Sleeve', ' Solid', ' Cotton', NULL, NULL, NULL, NULL, 10),
(20102, 'Peter England Men Blue Jeans', '909', 'images/Clothing/peter-england-men-blue-jeans.jpeg', 'Peter England', 'Jeans', 'RetailNet', 'Blue', '32', '', '', '', ' Cotton Lycra Blend', '', '', ' Button', ' Mid Rise', 11),
(20103, 'Superhero Men Hooded Blue T-Shirt', '410', 'images/Clothing/superhero-men-hooded-blue-tshirt.jpeg', 'Urbano Fashion ', 'T-shirt', ' ImperialClothing', 'Blue', 'Large', ' Slim', ' Full Sleeve', 'Superhero', ' Cotton Blend', ' Hooded', '', '', '', 5),
(20104, 'Printed Men Round Neck White T-Shirt', '548', 'images/Clothing/printed-men-round-neck-white-tshirt.jpeg', 'Spykar ', 'T-shirt', 'FasionNet', 'White', 'Medium', ' Slim', ' Half Sleeve', ' Printed', ' Cotton Blend', ' Round Neck', '', '', '', 10),
(20105, 'Men Self Design Formal Spread Shirt', '820', 'images/Clothing/men-self-design-formal-spread-shirt.jpeg', 'Peter England ', 'Shirt', 'RetailNet', 'Blue', '42', 'Slim', 'Full Sleeve', 'Self Design', 'Polycotton', '', '', '', '', 6);

-- --------------------------------------------------------

--
-- Table structure for table `mobiles`
--

CREATE TABLE `mobiles` (
  `productId` int(11) NOT NULL,
  `productName` varchar(50) DEFAULT NULL,
  `productPrize` int(7) DEFAULT NULL,
  `image` varchar(60) DEFAULT NULL,
  `brandName` varchar(50) NOT NULL,
  `color` varchar(25) DEFAULT NULL,
  `RAM` varchar(10) DEFAULT NULL,
  `ROM` varchar(10) DEFAULT NULL,
  `display` varchar(50) DEFAULT NULL,
  `camera` varchar(50) DEFAULT NULL,
  `battery` varchar(20) DEFAULT NULL,
  `operatingSystem` varchar(50) DEFAULT NULL,
  `seller` varchar(40) DEFAULT NULL,
  `weight` varchar(10) DEFAULT NULL,
  `productDescription` varchar(200) DEFAULT NULL,
  `availableItems` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobiles`
--

INSERT INTO `mobiles` (`productId`, `productName`, `productPrize`, `image`, `brandName`, `color`, `RAM`, `ROM`, `display`, `camera`, `battery`, `operatingSystem`, `seller`, `weight`, `productDescription`, `availableItems`) VALUES
(10101, 'Apple iPhone 7 Plus', 60780, 'images/Mobiles/apple-iphone-7-plus.jpeg', 'Apple', 'Black', '2 GB', '128 GB', '13.97 cm (5.5 inch)', '12MP + 12MP | 7MP Front Camera', ' Li-Ion', ' iOS 10', ' PrimeTrading', '188 gm', 'The iPhone 7 Plus brings to you a heady combination of style and performance to enhance your smartphone experience. With its impressive internal storage, powerful camera system and long battery life.', 10),
(10102, 'Redmi Note 6 Pro', 13999, 'images/Mobiles/Redmi-Note-6-Pro.jpeg', 'Xiaomi', 'Black', '4 GB', '64 GB', ' 15.9 cm (6.26 inch)', '12MP + 5MP | 20MP + 2MP Dual Front Camera', '4000 mAh', ' Android Oreo 8.1', ' SuperComNet', ' 181 gm', '\r\nSay hello to Redmi Note 6 Pro - Xiaomi\'s first smartphone that boasts an AI-powered quad-camera. Now enjoy a smart camera experience with the AI Scene Detection feature.', 4),
(10103, 'Samsung Galaxy A8 Star ', 29990, 'images/Mobiles/samsung-galaxy-a8-star.jpeg', 'Samsung', 'White', '6 GB ', '64 GB', ' 16.0 cm (6.3 inch)HD', '24MP', '3700 mAh', ' Android Oreo 8', ' BestGenuineDealsSLP', '176 gm', 'Galaxy A8 Star features an ergonomic, near bezel-less design that minimizes distraction so you can comfortably keep watching over what’s on screen.', 15),
(10104, 'Vivo V9 Pro', 14990, 'images/Mobiles/vivo-v9-pro.jpeg', 'Vivo', 'Black', '4 GB', '64 GB', '16.0 cm (6.3 inch)', '13MP + 2MP | 16MP Front Camera', '3260 mAh', ' Android Oreo 8.1', ' Flashtech Retail', ' 150 gm', '\r\nUp your picture-taking game with the Vivo V9 Pro smartphone. It comes with a high-resolution 16 MP selfie camera and a 13 MP + 2 MP dual rear camera system.', 3),
(10105, 'Samsung Galaxy J6', 10480, 'images/Mobiles/samsung-galaxy-j6.jpeg', 'Samsung', 'Blue', '3 GB', '32 GB', '14.22 cm (5.6 inch)', '13MP Rear Camera | 8MP Front Camera', '3000 mAh', 'Android Oreo 8', 'TrueComRetail', ' 153 gm', 'The Samsung Galaxy J6 is here, with its virtually continuous Bezel-free Screen, to make work and entertainment seem even more appealing.', 15),
(10106, 'Vivo Y93', 12880, 'images/Mobiles/vivo-y93.jpeg', 'Vivo', 'Starry Black', '3 GB', '64 GB', '15.8 cm (6.22 inch)', '13MP + 2MP | 8MP Front Camera', '4030 mAh', ' Android Oreo 8.1', ' Flashtech Retail', '163 gm', 'Capture picture-perfect shots despite the lighting or the background; this quest is made possible with the Vivo Y93', 10),
(10107, 'Redmi Note 5 Pro', 13999, 'images/Mobiles/redmi-note-5-pro.jpeg', 'Xiaomi', 'Gold', '6 GB', '64 GB', '15.21 cm (5.99 inch) HD', '12MP + 5MP | 20MP Front Camera', '4000 mAh', ' Android Nougat 7.1.2', ' SuperComNet', ' 181 g', ' Its 12 MP + 5 MP dual rear camera lets you can capture beautiful moments while the 1.8 GHz Snapdragon 636 processor lets you multitask on this phone without a lag.', 11),
(10108, 'Redmi 5A Mi', 5999, 'images/Mobiles/redmi-5a-mi.jpeg', 'Xiaomi', 'Gray', '2 GB', '16 GB', '12.7 cm (5 inch) HD', '13MP Rear Camera | 5MP Front Camera', '3000 mAh', ' Android Nougat 7.1.2', ' SuperComNet', '137 gm', 'Upgrade to the Redmi 5A smartphone that boasts a fully-laminated HD display. Play games, watch videos, and much more on this phone.', 0),
(10109, 'Apple iPhone 6s', 28999, 'images/Mobiles/apple-iphone-6s.jpeg', 'Apple', 'Silver', '6 GB', '32 GB', '11.94 cm (4.7 inch) Retina', '12MP Rear Camera | 5MP Front Camera', '1715 mAh', ' iOS 9', ' SuperComNet', '143 g', 'The iPhone 6s features a unibody design that is easy to hold. Bead-blasted aluminum is used to give this phone\'s body an elegant matte finish.', 8),
(10110, 'Samsung Galaxy J4 Plus', 8490, 'images/Mobiles/samsung-galaxy-j4-plus.jpeg', 'Samsung', 'Black', '2 GB', '32 GB', '15.24 cm (6 inch) HD', '13MP Rear Camera | 5MP Front Camera', '3300 mAh', ' Android Oreo 8.1', ' TrueComRetail', '178 g', 'You can stream your favorite TV shows or videos and watch them in stunning clarity on its 15.26 cm (6) True HD+ Infinity display.', 5),
(10111, 'Samsung Galaxy Note 9', 59900, 'images/Mobiles/samsung-galaxy-note-9.jpeg', 'Samsung', 'Ocean Blue', '6 GB', '128 GB', '16.26 cm (6.4 inch) Quad HD', '12MP + 12MP | 8MP Front Camera', '4000 mAh', ' Android Oreo 8', ' CellHaven', ' 201 g', 'The Samsung Galaxy Note 9 puts a new spin on the term as an interactive smartphone. It simplifies the way you work on your hand-held device to the way you charge it, and everything else in between.', 13),
(10112, 'Samsung Galaxy S8', 39990, 'images/Mobiles/samsung-galaxy-s8.jpeg', 'Samsung', 'Midnight Black', '4 GB', '64 GB', '14.73 cm (5.8 inch) Quad HD', '12MP Rear Camera | 8MP Front Camera', '3000 mAh', ' Android Nougat 7', ' TrueComRetail', '171 gm', 'Featuring the innovative Infinity Display, this smartphone offers a smooth, curved surface without sharp angles. With an array of security features, such as the Iris Scanner', 3),
(10113, 'Apple iPhone 8', 68999, 'images/Mobiles/apple-iphone-8.jpeg', 'Apple', 'Gold', '8 GB', '256 GB', '11.94 cm (4.7 inch) Retina', '12MP Rear Camera | 7MP Front Camera', '4200 mAh', ' iOS iOS 11', ' SuperComNet', ' 148 g', 'An all-new glass design, an updated camera, and a powerful chip, there\'s so much to love about the iPhone 8.  Siri and Dictation are there.', 5),
(10114, 'Samsung Galaxy A9', 30990, 'images/Mobiles/samsung-galaxy-a9.jpeg', 'Samsung', 'Bubblegum Pink', '6 GB', '128 GB', '16.0 cm (6.3 inch) FHD', '24MP + 5MP | 24MP Front Camera', '3800 mAh', 'Android Oreo 8', ' Flashtech Retail', '183 g', 'It comes equipped with a Quad Camera system, a fingerprint sensor, and offers a large internal storage space (128 GB) and Face Unlock to ensure that you put an end to your habit of ‘compromise’.', 4),
(10115, 'Redmi Note 4', 10999, 'images/Mobiles/redmi-note-4.jpeg', 'Xiaomi', 'Gold', '4GB', '64GB', '13.97 cm (5.5 inch)', '13 MP Rear camera | 5MP Front Camera', '4100 mAh', 'Android Marshmallow 6.0.1', 'SuperComNet', '165kg', 'large display on the Redmi Note 4 is perfect for watching movies,playing games and much more', 8),
(10116, 'Redmi Y2', 11499, 'images/Mobiles/redmi-y-2.jpeg', 'Xiaomi', 'Black', '4GB', '64GB', '15.21 cm (5.99 inch)HD+', '12 MP + 5MP | 16MP Front camera', '3080 mAH', 'Android Oero 8.0', 'Shreeetelecom', '168kg', 'Its slim design and natural curves give the Redmi Y2 a stylish and premium look.', 10),
(10117, 'Redmi 6', 8499, 'images/Mobiles/redmi-6.jpeg', 'Xiaomi', 'Blue', '3GB', '64GB', '13.84 cm (5.45 inch) HD+', '12MP + 5MP | 5MP Front camera', '3000mAh', 'Android Oreo 8.1', 'SuperComNet', '146kg', 'The portrait mode on the front camera blurs out the background perfectly to give you incredible bokeh selfies.', 12),
(10118, 'Vivo V11', 19990, 'images/mobiles/vivo-v11.jpeg', 'Vivo', 'Nebula purple', '6 GB', '64 GB', '16.0 cm (6.3 inch) + FHD', '16MP + 5MP | 25MP Front camera', '3315 mAh', 'Android Oreo 8.1', 'Flashtech Retailer', '163.7kg', 'Captures life\'s wonderful moments with the help of this phone\'s Dual rear Camera.', 13),
(10119, 'Vivo NEX', 39990, 'images/Mobiles/vivo-nex.jpeg', 'Vivo', 'Black', '8 GB', '128 GB', '16.74 cm (6.59 inch) FHD', '12 MP + 5MP | 8MP Front camera', '4000 mAh', 'Android Oreo 8.1', 'Flashtech Retail', '199 kg', '-', 6),
(10120, 'Vivo X21', 26990, 'images/Mobiles/vivo-x-21.jpeg', 'Vivo', 'Black', '6 GB ', '128 GB', '15.95 cm (6.28 inch) FHD', '2*12 MP + 5MP | 2*12 MP Front camera', '3200 mAh', 'Android Oreo 8.1', 'Flashtech Retail ', '156.2kg', 'The Hi-Fi Audio chip along with vivo\'s customized deep field technology amplifies the bass and enriches the vocal to give you clear,true-to-life audio experience.', 7),
(10121, 'Vivo Y83', 13990, 'images/Mobiles/vivo-y-83.jpeg', 'Vivo', 'Gold', '4 GB', '32 GB', '15.8 cm (6.22 inch) HD', '13 MP Rear camera | 8 MP Front camera', '3260 mAh', 'Android Oreo 8.1', 'Flashtech Retail', '151 kg', 'Features such as Portrait mode,AI face beauty,the Y83 lets you do some really cool stuff.', 15),
(10122, 'Apple iPhone XR', 70990, 'images/Mobiles/apple-iphone-xr.jpeg', 'Apple', 'White', '2GB', '64 GB', '15.49 cm (6.1 inch)', '12 MP Rear camera | 7MP Front camera', 'Li-lon', 'iso 12', 'CreativeDealSLP', '194 g', 'iPhone has arrived to stun our senses with a host of features such as Faster face id,and the powerful A12 bionic chip.', 5),
(10123, 'Apple iPhone SE', 23999, 'images/Mobiles/apple-iphone-se.jpeg', 'Apple', 'Rose Gold', '8GB', '32GB', '10.16 cm', '12 MP Rear camera | 1.2 MP Front camera', 'Li-Ion', 'iOS 10', 'PrimeTrading', '113g', 'A Special Appple-Designed alloy has been utilized to make the structural bands to complement the look of the back glass.', 10),
(10124, 'Apple iPhone 8 Plus', 79999, 'images/Mobiles/apple-iphone-8-plus.jpeg', 'Apple', 'Silver', '2GB', '256 GB', '13.97 cm (5.5 inch) Retina HD', '12 MP + 12 MP |7 MP Front camera', 'Li-Ion', 'iOS iOS 11', 'SuperComNet', '202g', 'Its body is precision-engineered to be splash,water,and dust resistant.', 5);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderId` int(11) NOT NULL,
  `orderDate` varchar(30) NOT NULL,
  `expDeliveryDate` varchar(30) NOT NULL,
  `productIds` varchar(60) NOT NULL,
  `custId` int(6) NOT NULL,
  `orderAmount` int(6) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `payMode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderId`, `orderDate`, `expDeliveryDate`, `productIds`, `custId`, `orderAmount`, `quantity`, `payMode`) VALUES
(7, '19-05-2019', '24-05-2019', '0_10103', 2, 59980, '0_2', 'cod'),
(8, '19-05-2019', '24-05-2019', '0_20101_10101', 3, 62493, '0_3_1', 'Debit'),
(9, '05-02-2020', '10-02-2020', '0_10105', 5, 10480, '0_1', 'cod'),
(10, '05-02-2020', '10-02-2020', '0_10104_10110_20101_10104_10103', 5, 69041, '0_1_1_1_1_1', 'cod'),
(11, '05-02-2020', '10-02-2020', '0_40101', 5, 1495, '0_1', 'cod'),
(12, '05-02-2020', '10-02-2020', '0_10102_10103_25101_25101_20102_40106', 5, 49809, '0_1_1_1_3_1_1', 'cod'),
(13, '19-03-2020', '24-03-2020', '0_10102_10103', 7, 57988, '0_2_1', 'cod');

-- --------------------------------------------------------

--
-- Table structure for table `sportswear`
--

CREATE TABLE `sportswear` (
  `productId` int(11) NOT NULL,
  `productName` varchar(50) DEFAULT NULL,
  `productPrize` varchar(6) DEFAULT NULL,
  `image` varchar(60) DEFAULT NULL,
  `brandName` varchar(50) DEFAULT NULL,
  `clothingCategory` varchar(15) DEFAULT NULL,
  `seller` varchar(40) DEFAULT NULL,
  `color` varchar(25) DEFAULT NULL,
  `size` varchar(15) DEFAULT NULL,
  `neckType` varchar(25) DEFAULT NULL,
  `idealFor` varchar(15) DEFAULT NULL,
  `fit` varchar(20) DEFAULT NULL,
  `sleeve` varchar(25) DEFAULT NULL,
  `pattern` varchar(25) DEFAULT NULL,
  `fabric` varchar(25) DEFAULT NULL,
  `closure` varchar(15) DEFAULT NULL,
  `pockets` varchar(25) DEFAULT NULL,
  `availableItems` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sportswear`
--

INSERT INTO `sportswear` (`productId`, `productName`, `productPrize`, `image`, `brandName`, `clothingCategory`, `seller`, `color`, `size`, `neckType`, `idealFor`, `fit`, `sleeve`, `pattern`, `fabric`, `closure`, `pockets`, `availableItems`) VALUES
(35101, 'Printed Men Blue T-Shirt', '779', 'images/Clothing/printed-men-blue-tshirt.jpeg', 'Reebok', 'T-Shirt', ' RetailNet', ' Blue', NULL, ' Round Neck', 'Men', ' Regular', ' Half Sleeve', ' Printed', ' Polyster', NULL, NULL, 4),
(35102, 'Hanes Solid Men Blue Track Pants', '636', 'images/Clothing/hens-solid-men-blue-track-pants.jpeg', 'Hanes ', 'Track Pants', ' RetailNet', ' Blue', 'Medium', '', '', '', '', ' Solid', '', ' Knot', ' 2 Slant Pockets', 6),
(35103, 'Solid Men Grey Track Pants', '584', 'images/Clothing/solid-men-grey-track-pants.jpeg', 'Metronaut', 'Track Pants', 'SuperCom', 'Grey', 'XL', '', '', '', '', ' Solid', ' COTTON/POLYSTER', '', '', 5),
(35104, 'Fila Solid Men Black Sports Shorts', '599', 'images/Clothing/filla-solid-men-black-sports-shorts.jpeg', 'Fila ', 'Shorts', ' RetailNet', 'Black', 'Large', '', '', '', '', 'Solid', 'Cotton Blend', ' Elasticated', '2 front pockets', 5),
(35105, 'Adidas Printed Men Round Maroon T-Shirt', '808', 'images/Clothing/adidas-printed-men-round-maroon-tshirt.jpeg', 'Adidas', 'T-shirt', 'RetailNet', 'Maroon', 'Large', ' Round or Crew', 'Men', ' Regular', ' Half Sleeve', 'Printed', ' Cotton Blend', '', '', 5),
(35108, 'tshirt', '2500', 'images/Clothing/nike.jpg', 'nike', 'T-shirt', 'sky', 'black', 'm', 'round', 'men', 'regular', 'half', 'black', 'cotton', 'null', 'null', 10);

-- --------------------------------------------------------

--
-- Table structure for table `watches`
--

CREATE TABLE `watches` (
  `productId` int(11) NOT NULL,
  `productName` varchar(50) DEFAULT NULL,
  `productPrize` varchar(6) DEFAULT NULL,
  `image` varchar(60) DEFAULT NULL,
  `brandName` varchar(25) DEFAULT NULL,
  `seller` varchar(40) DEFAULT NULL,
  `waterResistant` varchar(15) DEFAULT NULL,
  `displayType` varchar(20) DEFAULT NULL,
  `diameter` varchar(15) DEFAULT NULL,
  `thickness` varchar(15) DEFAULT NULL,
  `material` varchar(40) DEFAULT NULL,
  `warranty` varchar(20) DEFAULT NULL,
  `availableItems` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `watches`
--

INSERT INTO `watches` (`productId`, `productName`, `productPrize`, `image`, `brandName`, `seller`, `waterResistant`, `displayType`, `diameter`, `thickness`, `material`, `warranty`, `availableItems`) VALUES
(40101, 'Fastrack Bare Basic Watch - Men', '1495', 'images/Watches/fastrack-NG312-basic-watch.jpeg', 'Fastrack', ' RetailNet', ' Yes', ' Analog', ' 41 mm', ' 13 mm', 'Plastic Dial', '2 years', 11),
(40102, 'casio', '2500', 'images/Watches/images (1).jpg', 'casio', 'RetailNet', 'Yes', '40mm', '13.5 mm', '12mm', 'Silicone Strap', '1 year', 12),
(40103, 'Titan Neo series Watch', '1956', 'images/Watches/titan-neo-watch.jpeg', 'Titan', ' RetailNet', ' Yes', ' Analog', ' 40 mm', '12 mm', 'Plastic Dial', '1 year', 5),
(40104, 'Fossil MACHINE Watch - Men', '9995', 'images/Watches/fossil-machine-watch.jpeg', 'Fossil', ' RetailNet', 'Yes', ' Analog', '45 mm', ' 22 mm', 'stainless steel', '2 years', 3),
(40105, 'Casio EX190 Edifice watch', '8395', 'images/watches/casio-ex-190-edifice-watch.jpeg', 'Casio', 'RetailNet', 'Yes', 'Analog', '49.5mm', '11.7mm', 'Stainless Steel Strap', '2 Years', 10),
(40106, 'Fastrack NG6093SM01C Watch', '2395', 'images/watches/fastrack-ng6093sm01c-watch.jpeg', 'Fastrack', 'RetailNet', 'Yes', 'Analog', '21mm', '7mm', 'Metal strap', '1 Year', 6),
(40107, 'Titan 1730SL02 Watch', '2395', 'images/watches/titan-1730sl02-watch.jpeg', 'Titan', 'RetailNet', 'Yes', 'Analog ', '34mm', '7mm', 'stainless Steel Material', '2 Years', 14),
(40108, 'Fossil TOWNSMAN Watch', '18295', 'images/watches/fossil-townsman-watch.jpeg', 'Fossil', 'RetailNet', 'Yes', 'Analog', '44mm', '22mm', 'Leather Strap', '2years', 16),
(40109, 'Fossil C2600IE Watch', '6495', 'images/watches/fossil-c2600ie-watch.jpeg', 'Fossil', 'RetailNet', 'Yes', 'Anaolg', '44mm', '22mm', 'Stainless Steel Strap', '2 Years', 10),
(40110, 'Casio A550 Enticer Men Watch', '2498', 'images/watches/casio-a550-enticer-men-watch.jpeg', 'Casio', 'RetailerNet', 'Yes', 'Analog', '44.9mm', '9.4mm', 'stainless Steel Strap', '2Year', 5),
(40111, 'Titan 1584SL03 Analog Watch', '2395', 'images/watches/titan-1584SL03-analog-watch.jpeg', 'Titan', 'RetailNet', 'Yes', 'Analog', '35mm', '7mm', 'Stainless Steel Case', '2Years', 12),
(40112, 'Fastrack 38035SL04 Watch', '3995', 'images/watches/fastrack-38035sl04-watch.jpeg', 'Fastrack', 'RetailNet', 'Yes', 'Analog', '35 mm', '18 mm', 'Stainless Steel Material', '1 Years', 6),
(40113, 'Titan 1562WL02 Classique Watch', '8495', 'images/watches/titan-1562wl02-classique-watch.jpeg', 'Titan', 'RetailNet', 'Yes', 'Analog', '36mm', '12 mm', 'Stainless Steel', '2 Years', 4),
(40114, 'Fossil BQ1009 RHETT Watch', '5613', 'images/watches/fossil-bq1009-rhett-watch.jpeg', 'Fossil', 'RetailNet', 'Yes', 'Analog', '42mm', '10 mm', 'Stainless Steel', '2 Years', 10),
(40115, 'Casio A950 Enticer Watch', '4695', 'images/watches/casio-a950-enticer-watch.jpeg', 'Casio', 'RetailNet', 'Yes', 'Analog', '43.5mm', '10.4mm', 'Stainless Steel Strap', '2 Years', 8),
(40117, 'Casio D099 Youth Series Watch', '2795', 'images/watches/casio-d099-youth-series-watch.jpeg', 'Casio', 'BappaAssociation', 'Yes', 'Digital', '42.1mm', '12.5mm', 'Stainless Steel Strap', '2 Years', 11),
(40118, 'Casio A1479 Enticer Men\'s Watch', '3836', 'images/watches/casio-a1479-enticer-mens-watch.jpeg', 'Casio', 'RetailNet', 'Yes', 'Analog', '41.1mm', '10.7mm', 'StainlessSteel', '2 Years', 13),
(40119, 'Titan 2594SM01 Karishma Revive Watch', '1695', 'images/watches/titan-2594sm01-karishma-revive-watch.jpeg', 'Titan', 'RetailNet', 'Yes', 'Analog', '5.2 mm', '6 mm', 'Thin Strap', '1 Years', 17),
(40120, 'Titan NH2539KM01 Raga Watch', '7295', 'images/watches/titan-nh2539km01-raga-watch.jpeg', 'Titan', 'RetailernNet', 'Yes', 'Analog', '29 mm', '7.40mm', 'Brass Strap', 'Years', 14),
(40121, 'Fossil FS5403 COMMUTER Watch', '9995', 'images/watches/fossil-fs5403-commuter-watch.jpeg', 'Fossil', 'RetailNet', 'Yes', 'Analog', '42mm', '12mm', 'Stainless Steel', '2 Years', 3),
(40122, 'Fossil ME3110 Townsman Watch', '13995', 'images/watches/fossil-me3110-townsman-watch.jpeg', 'Fossil', 'FossiIIndia', 'Yes', 'Analog', '44mm', '12mm', 'Stainless Steel', '2 Years', 9),
(40123, 'Fastrack NG3084NM01 Watch', '3650', 'images/watches/fastrack-ng3084nm01-watch.jpeg', 'Fastrack', 'RetailerNet', 'Yes', 'Analog', '36 mm', '12 mm', 'Stainless Steel', '1 Years', 13),
(40124, 'Fastrack  38003PP19 Analog Watch', '950', 'images/Watches/fastrack-38003PP19-analog-watch.jpeg', 'Fastrack', ' RetailNet', ' Yes', ' Analog', '40 mm', '13.5 mm', ' Silicone Strap', '6 Months', 0),
(40125, 'fastrack', '2500', 'images/Watches/download (3).jpg', 'fastrack', 'BappaAssociation', 'yes', 'Analog', '5.2 mm', '6 mm', '	 Brass Strap', '1 year ', 14),
(40126, 'casio', '4500', 'images/Watches/download (4).jpg', 'Casio', 'CrystalarscLifestyle', 'yes', 'Analog', '48 mm', '14 mm', 'Stainless Steel', '1 year', 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `bankaccount`
--
ALTER TABLE `bankaccount`
  ADD PRIMARY KEY (`accountId`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `childrenswear`
--
ALTER TABLE `childrenswear`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`custId`);

--
-- Indexes for table `deliveryboy`
--
ALTER TABLE `deliveryboy`
  ADD PRIMARY KEY (`dbId`);

--
-- Indexes for table `ladieswear`
--
ALTER TABLE `ladieswear`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `menswear`
--
ALTER TABLE `menswear`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `mobiles`
--
ALTER TABLE `mobiles`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `sportswear`
--
ALTER TABLE `sportswear`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `watches`
--
ALTER TABLE `watches`
  ADD PRIMARY KEY (`productId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bankaccount`
--
ALTER TABLE `bankaccount`
  MODIFY `accountId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50126;

--
-- AUTO_INCREMENT for table `childrenswear`
--
ALTER TABLE `childrenswear`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30107;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `custId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `deliveryboy`
--
ALTER TABLE `deliveryboy`
  MODIFY `dbId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ladieswear`
--
ALTER TABLE `ladieswear`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25107;

--
-- AUTO_INCREMENT for table `menswear`
--
ALTER TABLE `menswear`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20106;

--
-- AUTO_INCREMENT for table `mobiles`
--
ALTER TABLE `mobiles`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10125;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sportswear`
--
ALTER TABLE `sportswear`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35109;

--
-- AUTO_INCREMENT for table `watches`
--
ALTER TABLE `watches`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40127;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
