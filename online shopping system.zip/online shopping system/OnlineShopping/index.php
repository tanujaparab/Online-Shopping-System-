<!DOCTYPE html>
<html>
 <head>
  <title>
	 Shop Online - Home
  </title>
  <link rel="stylesheet" type="text/css" href="css/index.css">   
 </head>
	
  <body>
  	<div id="wrapper">
	  <!---------------Header Content---------------------->
	  
	  <?php  include("include-files/header.php");  
		
		/* following three header lines are used to reload the page
		   while everytime user hit back button in browser*/
	    include("include-files/cacheHeader.php");
		
	  ?>
		
	  <!---------------Product Categories--------------------->
		
	  <?php  include("include-files/productCategoryBox.php");  ?>
	 
	  <?php		
		function showProduct($proId) {
		   $con = mysqli_connect("localhost","root","","onlineshopping") or        
		   die(mysqli_connect_error());
			
		   if($proId <= 20100) {
			 $qry = mysqli_query($con,"select productName, productPrize, image from mobiles where productId='$proId'");  
		   } else if($proId >= 20101 && $proId <= 25100) {
			  $qry = mysqli_query($con,"select  productName, productPrize, image from menswear where productId='$proId'"); 
		   }else if($proId >= 25101 && $proId <= 30100) {
			  $qry = mysqli_query($con,"select  productName, productPrize, image from ladieswear where productId='$proId'"); 
		   }else if($proId >= 30101 && $proId <= 35100) {
			  $qry = mysqli_query($con,"select  productName, productPrize, image from childrenswear where productId='$proId'"); 
		   }else if($proId >= 35101 && $proId <= 40100) {
			  $qry = mysqli_query($con,"select  productName, productPrize, image from sportswear where productId='$proId'"); 
		   }else if($proId >= 40101 && $proId <= 50100) {
			  $qry = mysqli_query($con,"select  productName, productPrize, image from watches where productId='$proId'"); 
		   }
		   else if($proId >= 50101 && $proId <= 60100) {
			  $qry = mysqli_query($con,"select  productName, productPrize, image from books where productId='$proId'"); 
		   }
			
		   $res = mysqli_fetch_row($qry);
	       $proName = $res[0]; 
           $proPrize = $res[1];
           $proImg = $res[2];
			
		   echo "<a href='product-files/viewProduct.php?proId=$proId'>";
			echo "<span class='tdBody'>";
			 echo "<img src='$proImg' width='70' height='130'/><br>";
			 echo $proName."<br>";
			 echo "<span class='proPrize'>";
			   echo  "Prize: &#8377;".$proPrize."<br>"; 
			 echo "</span>";
			echo "</span> ";
		   echo "</a>"; 
		}
	  ?>
	
	  <div id="productTableDiv">
		<table id="productTable">
	     <tr>
		  <td class="productBox"> <?php showProduct(10101); ?> </td> 
		  <td class="productBox"> <?php showProduct(10102); ?> </td>
		  <td class="productBox"> <?php showProduct(10103); ?> </td>
		  <td class="productBox"> <?php showProduct(10104); ?> </td>
	     </tr>
	     <tr>
		  <td class="productBox"> <?php showProduct(20101); ?> </td>
		  <td class="productBox"> <?php showProduct(25101); ?> </td>
		  <td class="productBox"> <?php showProduct(30101); ?> </td>
		  <td class="productBox"> <?php showProduct(35101); ?> </td>
		 </tr>
		 <tr>
		  <td class="productBox"> <?php showProduct(40101); ?> </td>
		  <td class="productBox"> <?php showProduct(40102); ?> </td>
		  <td class="productBox"> <?php showProduct(40103); ?> </td>
		  <td class="productBox"> <?php showProduct(40104); ?> </td>
		 </tr>
	     <tr>
		  <td class="productBox"> <?php showProduct(50101); ?> </td>
		  <td class="productBox"> <?php showProduct(50102); ?> </td>
		  <td class="productBox"> <?php showProduct(50103); ?> </td>
		  <td class="productBox"> <?php showProduct(50104); ?> </td>
		 </tr>
	    </table>
	  </div> 
	
	  <?php
		if(!isset($_SESSION["userId"])) {
			
		} else {
			
	  ?>
	  <a href="myOrders.php">
	  <div id="myOrders">
		My orders
	  </div>
	  </a><br><br>
		
	  <?php
		}
	  ?>
		
	  <div id="offers">
		<img src="images/offer.PNG"/>
	  </div>
		
	<!--  <div id="footer">
		<span class="contact">
		  <h3>Mail Us</h3><br>
		  Cartmagic Pvt Ltd Company,<br>
          Ground Floor, Skyline Tech Park,<br>
          21st Road, Andheri(W),<br>
          Mumbai, India 421506<br>
        </span>
        
		<span class="contact">
		  <h3>Toll Free Numbers</h3>
		   1800 2562 214<br>
		   1800 2571 228
		</span>  
	  </div> --->
	  
	</div>
	  
  </body>
</html>