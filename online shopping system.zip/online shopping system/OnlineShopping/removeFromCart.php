<?php
  if(isset($_REQUEST['removeProId'])) {
	  $removeProId = $_REQUEST['removeProId'];
	  
	  session_start();
	  if(isset($_SESSION["userId"])) {
		  
		  //--------------To remove cart Items------------------
	      $custId = $_SESSION["userId"];
		  include("include-files/dbConnection.php");
		  
		  $qry = mysqli_query($con,"select * from customers where custId='$custId'");
	      $res = mysqli_fetch_array($qry);
	      $accCartItems = $res["cartProducts"];
	      $accCartQty = $res["cartQtys"];
		  
		  $productArray = explode("_",$accCartItems);
	      $noOfProducts = count($productArray);
		  
	      $i = 0;
	      while($i < $noOfProducts) {
            if($removeProId == $productArray[$i]){
		    $indexOfId = $i;
            unset($productArray[$i]);    
          }
           $i++;
          }
		  $newItemsArray = $productArray;
		  $accCartItems = implode("_",$newItemsArray);
		  
		  //--------------To remove quantities------------------
		  $qtyArray = explode("_",$accCartQty);
	      unset($qtyArray[$indexOfId]);
		  $newQtyArray = $qtyArray;
		  $accCartQty = implode("_",$newQtyArray);
		  
		  //----------Updating cart and Qty-----------------------
		  $updateQry = mysqli_query($con,"update customers set cartProducts='$accCartItems', cartQtys='$accCartQty' where custId='$custId'");
	  
	      mysqli_close($con);
		  header("location:myCart.php"); 
	  } else {
		  
	  //--------------To remove cart Items------------------
	  $cartItems = $_COOKIE['cartItems'];
	  $productArray = explode("_",$cartItems);
	  $noOfProducts = count($productArray);
	  
	  $i = 0;
	  while($i < $noOfProducts) {
        if($removeProId == $productArray[$i]){
		  $indexOfId = $i;
          unset($productArray[$i]);    
        }
        $i++;
     } 
	    $newCartArray = $productArray;
     $cartItems = implode("_",$newCartArray);
     setcookie("cartItems",$cartItems,time()+(86400*60));
	  
	 //--------------To remove quantities------------------
	 $quantities = $_COOKIE['quantities'];
	 $qtyArray = explode("_",$quantities);
	 unset($qtyArray[$indexOfId]);
	  
	 $newQtyArray = $qtyArray;
	 $quantities = implode("_",$newQtyArray);
	 setcookie("quantities",$quantities,time()+(86400*60));
	  
	 header("location:myCart.php");  
   }
	    
 } else {
	  header("location:myCart.php");
 }
?>